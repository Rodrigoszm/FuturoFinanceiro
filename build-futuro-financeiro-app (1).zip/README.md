# 💚 Futuro Financeiro

Aplicativo de educação financeira — **PWA instalável** no celular.

> Stack: React 19 · Vite 7 · TypeScript · Tailwind CSS v4 · Firebase (opcional) · PWA

---

## 🗂️ Estrutura do Projeto

```
futuro-financeiro/
├── public/
│   ├── icon-192.png          ← Ícone PWA 192×192
│   ├── icon-512.png          ← Ícone PWA 512×512
│   ├── manifest.webmanifest  ← Manifest PWA
│   └── sw.js                 ← Service Worker
├── src/
│   ├── App.tsx
│   ├── main.tsx
│   ├── index.css
│   ├── types.ts
│   ├── nav.ts
│   ├── auth/                 ← AuthContext, AuthGate, session, types
│   ├── components/
│   │   ├── brand/            ← Logo, Splash, Loading
│   │   ├── calc/             ← Calculadoras
│   │   ├── finance/          ← DonutChart
│   │   ├── icons/            ← NavIcons SVG
│   │   ├── layout/           ← Header, MobileTabBar, BottomNav
│   │   └── ui/               ← Button, Card, Field, Modal, SectionTitle
│   ├── data/                 ← quizData, financeData, dicionario, economiaApi
│   ├── firebase/             ← config, auth, db
│   ├── hooks/                ← useLocalStorage
│   ├── pages/                ← Home, Aprender, Calculadoras, Moedas, Quiz,
│   │                            MeuDinheiro, Dicionario, Login, LoginPage
│   └── pwa/                  ← InstallPrompt, registerSW
├── .env.example              ← Modelo de variáveis de ambiente
├── .gitignore
├── index.html
├── package.json
├── tsconfig.json
├── vercel.json               ← Configuração de deploy na Vercel
├── vite.config.ts            ← Config padrão (singlefile, para preview)
└── vite.config.deploy.ts     ← Config de deploy (Vercel / produção)
```

---

## 🚀 Rodar Localmente

```bash
# 1. Instalar dependências
npm install

# 2. Criar arquivo de variáveis (opcional — sem Firebase funciona em modo local)
cp .env.example .env.local
# edite .env.local com as chaves do Firebase

# 3. Iniciar servidor de desenvolvimento
npm run dev

# 4. Abrir no navegador
# http://localhost:5173
```

---

## 📦 Build de Produção (para Vercel)

```bash
# Build otimizado com assets separados (necessário para PWA e Vercel)
npm run build:deploy

# Pré-visualizar o build localmente
npm run preview:deploy
```

> ⚠️ **Não use `npm run build`** para deploy — ele usa `vite-plugin-singlefile`
> que inlina tudo em um único HTML e quebra PWA / assets na Vercel.
> Use sempre `npm run build:deploy`.

---

## 🐙 Publicar no GitHub

```bash
# 1. Inicializar repositório (se ainda não fez)
git init

# 2. Adicionar todos os arquivos
git add .

# 3. Primeiro commit
git commit -m "feat: Futuro Financeiro v1.0 — PWA de educação financeira"

# 4. Criar repositório no GitHub (via site github.com) e conectar:
git remote add origin https://github.com/SEU_USUARIO/futuro-financeiro.git

# 5. Enviar para o GitHub
git push -u origin main
```

---

## ▲ Deploy na Vercel

### Opção A — Via interface web (recomendado)

1. Acesse [vercel.com](https://vercel.com) e faça login
2. Clique em **"Add New Project"**
3. Importe o repositório do GitHub
4. A Vercel detecta o `vercel.json` automaticamente
5. Em **"Environment Variables"**, adicione as variáveis do Firebase (se usar):

   | Variável | Valor |
   |---|---|
   | `VITE_FIREBASE_API_KEY` | sua chave |
   | `VITE_FIREBASE_AUTH_DOMAIN` | seu-projeto.firebaseapp.com |
   | `VITE_FIREBASE_PROJECT_ID` | seu-projeto-id |
   | `VITE_FIREBASE_STORAGE_BUCKET` | seu-projeto.appspot.com |
   | `VITE_FIREBASE_MESSAGING_SENDER_ID` | seu sender id |
   | `VITE_FIREBASE_APP_ID` | sua app id |

6. Clique em **"Deploy"** ✅

### Opção B — Via Vercel CLI

```bash
# Instalar Vercel CLI
npm i -g vercel

# Fazer login
vercel login

# Deploy
vercel --prod
```

---

## 🔥 Firebase (Opcional)

O app funciona **100% sem Firebase** usando localStorage.
Para ativar Firebase:

1. Crie um projeto em [console.firebase.google.com](https://console.firebase.google.com)
2. Ative **Authentication → Email/Password**
3. Ative **Firestore Database**
4. Nas regras do Firestore, use:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId}/{document=**} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

5. Copie as credenciais do projeto e adicione ao `.env.local`

---

## 📱 Instalar como PWA no Android

1. Abra o site no **Chrome para Android**
2. O banner "Instalar Futuro Financeiro" aparece automaticamente
3. Clique em **"Instalar App"**
4. O app é adicionado à tela inicial e abre em modo standalone (tela cheia)

---

## 🎯 Funcionalidades

| Página | Descrição |
|---|---|
| 🏠 Início | Dashboard com saudação, frase do dia, acesso rápido e dicas |
| 📚 Aprender | 6 categorias com explicações e exemplos brasileiros |
| 🧮 Calculadoras | Porcentagem, desconto, juros simples/compostos, parcelas |
| 📊 Moedas | Cotações em tempo real (USD, EUR, BTC, ETH, Ouro) |
| 🎯 Quiz | Quiz financeiro com temas, pontuação e medalhas |
| 💰 Meu Dinheiro | Controle de receitas/despesas com gráfico donut |
| 📖 Dicionário | 10 termos financeiros com busca e favoritos |
| 👤 Login | Autenticação local + Firebase com persistência |

---

## 🛠️ Tecnologias

- **React 19** + **TypeScript**
- **Vite 7** (bundler)
- **Tailwind CSS v4**
- **Firebase** (auth + firestore, opcional)
- **PWA** (manifest + service worker nativo)
- Sem dependências de roteamento externas

---

## 📄 Licença

MIT — use livremente para fins educacionais.
