/**
 * AuthContext com integração Firebase + fallback local.
 *
 * Estratégia:
 *  1. Se o Firebase estiver pronto (firebaseReady), tenta operar via Firebase Auth.
 *  2. Se falhar (sem rede, configuração ausente, erro de inicialização), cai
 *     automaticamente no modo local (mesma lógica de antes — localStorage).
 *  3. A sessão é restaurada com segurança no boot, com flag `loading` para
 *     evitar flicker.
 *
 * Importante: o splash, a navegação e o layout NÃO são modificados aqui.
 */
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import {
  makeFakeAvatar,
  makeToken,
  type Account,
  type User,
} from "./authTypes";
import { firebaseReady } from "../firebase/config";
import { fbLogin, fbLogout, fbOnAuthChange, fbSignup } from "../firebase/auth";
import {
  getSession,
  logout as clearSession,
  saveSession,
} from "./session";

interface AuthResult {
  ok: boolean;
  error?: string;
}

export type AuthMode = "firebase" | "local";

interface AuthContextValue {
  user: User | null;
  isAuthenticated: boolean;
  loading: boolean;
  mode: AuthMode;
  login: (email: string, password: string) => Promise<AuthResult>;
  signup: (name: string, email: string, password: string) => Promise<AuthResult>;
  logout: () => Promise<void>;
}

const ACCOUNTS_KEY = "ff_auth_accounts";

const AuthContext = createContext<AuthContextValue | null>(null);

/* ----------------------- local storage helpers ----------------------- */

function readAccounts(): Account[] {
  try {
    const raw = localStorage.getItem(ACCOUNTS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as Account[]) : [];
  } catch {
    // dados corrompidos → reseta para evitar loop de erro
    try {
      localStorage.removeItem(ACCOUNTS_KEY);
    } catch {
      /* ignore */
    }
    return [];
  }
}

function writeAccounts(accounts: Account[]) {
  try {
    localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(accounts));
  } catch {
    /* ignore */
  }
}

/* ----------------------------- local auth ---------------------------- */

function localSignup(name: string, email: string, password: string): AuthResult {
  const cleanEmail = email.trim().toLowerCase();
  if (!name.trim()) return { ok: false, error: "Informe seu nome." };
  if (!cleanEmail.includes("@")) return { ok: false, error: "E-mail inválido." };
  if (password.length < 4)
    return { ok: false, error: "A senha precisa de ao menos 4 caracteres." };

  const accounts = readAccounts();
  if (accounts.some((a) => a.email === cleanEmail))
    return { ok: false, error: "Este e-mail já está cadastrado." };

  const account: Account = {
    id: makeToken(),
    name: name.trim(),
    email: cleanEmail,
    password,
    avatar: makeFakeAvatar(name || cleanEmail),
    token: makeToken(),
    createdAt: new Date().toISOString(),
  };
  writeAccounts([...accounts, account]);
  return { ok: true };
}

function localLogin(email: string, password: string): {
  result: AuthResult;
  user?: User;
} {
  const cleanEmail = email.trim().toLowerCase();
  const accounts = readAccounts();
  const found = accounts.find((a) => a.email === cleanEmail);
  if (!found) return { result: { ok: false, error: "E-mail não cadastrado." } };
  if (found.password !== password)
    return { result: { ok: false, error: "Senha incorreta." } };

  const refreshed: Account = { ...found, token: makeToken() };
  writeAccounts(accounts.map((a) => (a.email === cleanEmail ? refreshed : a)));

  const { password: _pw, ...session } = refreshed;
  void _pw;
  return { result: { ok: true }, user: session };
}

/* ----------------------------- provider ------------------------------ */

export function AuthProvider({ children }: { children: ReactNode }) {
  // Restaura sessão do localStorage no boot (protegido contra JSON corrompido).
  const [user, setUser] = useState<User | null>(() => getSession());
  // Quando o Firebase está pronto, ficamos em loading até o primeiro snapshot.
  const [loading, setLoading] = useState<boolean>(firebaseReady);
  const [mode, setMode] = useState<AuthMode>(firebaseReady ? "firebase" : "local");

  // Guarda para garantir que o listener do Firebase é criado uma única vez.
  const subRef = useRef<null | (() => void)>(null);

  // Persiste a sessão sempre que o user muda (em ambos os modos).
  // saveSession/clearSession já têm try/catch internos.
  useEffect(() => {
    if (user) saveSession(user);
    else clearSession();
  }, [user]);

  // Listener seguro do Firebase (apenas se pronto). Cleanup robusto.
  useEffect(() => {
    if (!firebaseReady) {
      setLoading(false);
      return;
    }
    if (subRef.current) return; // já inscrito

    try {
      subRef.current = fbOnAuthChange((u) => {
        setUser(u);
        setLoading(false);
      });
    } catch {
      // Se falhar, voltamos ao modo local sem quebrar o app.
      setMode("local");
      setLoading(false);
    }

    return () => {
      try {
        subRef.current?.();
      } catch {
        /* ignore */
      }
      subRef.current = null;
    };
    // Sem dependências externas: efeito único de montagem.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ----------------------------- actions ---------------------------- */

  const signup = useCallback(
    async (name: string, email: string, password: string): Promise<AuthResult> => {
      // 1) tenta Firebase
      if (mode === "firebase" && firebaseReady) {
        const res = await fbSignup(name, email, password);
        if (res.ok && res.user) {
          setUser(res.user);
          return { ok: true };
        }
        // Se o erro indicar Firebase indisponível, faz fallback local.
        if (res.error === "Firebase indisponível") {
          setMode("local");
        } else {
          return { ok: false, error: res.error };
        }
      }
      // 2) modo local
      const localRes = localSignup(name, email, password);
      if (localRes.ok) {
        // logar automaticamente no fluxo local
        const { user: u } = localLogin(email, password);
        if (u) setUser(u);
      }
      return localRes;
    },
    [mode],
  );

  const login = useCallback(
    async (email: string, password: string): Promise<AuthResult> => {
      if (mode === "firebase" && firebaseReady) {
        const res = await fbLogin(email, password);
        if (res.ok && res.user) {
          setUser(res.user);
          return { ok: true };
        }
        if (res.error === "Firebase indisponível") {
          setMode("local");
        } else {
          return { ok: false, error: res.error };
        }
      }
      const { result, user: u } = localLogin(email, password);
      if (result.ok && u) setUser(u);
      return result;
    },
    [mode],
  );

  const logout = useCallback(async () => {
    // 1) tenta encerrar sessão no Firebase (silencioso se falhar)
    if (mode === "firebase" && firebaseReady) {
      try {
        await fbLogout();
      } catch {
        /* segue mesmo se falhar — vamos limpar localmente */
      }
    }
    // 2) limpa a sessão local (sessão + token) de forma segura
    clearSession();
    // 3) zera o estado em memória — o efeito ainda chamará clearSession() de novo,
    //    o que é idempotente.
    setUser(null);
  }, [mode]);

  const value = useMemo<AuthContextValue>(
    () => ({
      user,
      isAuthenticated: user !== null,
      loading,
      mode,
      login,
      signup,
      logout,
    }),
    [user, loading, mode, login, signup, logout],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth deve ser usado dentro de <AuthProvider>");
  return ctx;
}
