/**
 * AuthGate — protege o app principal.
 *
 *  - Enquanto a sessão está sendo restaurada: mostra um loading leve.
 *  - Se NÃO autenticado: mostra a LoginPage (tela cheia).
 *  - Se autenticado: renderiza os children (o app principal).
 *
 * Mínimo e isolado: não toca em splash, navegação, layout nem PWA.
 */
import type { ReactNode } from "react";
import { useAuth } from "./AuthContext";
import { LoginPage } from "../pages/LoginPage";
import { Logo } from "../components/brand/Logo";

interface AuthGateProps {
  children: ReactNode;
}

export function AuthGate({ children }: AuthGateProps) {
  const { isAuthenticated, loading } = useAuth();

  // Loading leve enquanto verifica a sessão (refresh, restauração do storage, etc.)
  if (loading) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-gradient-to-br from-emerald-950 via-emerald-900 to-emerald-950 text-white">
        <div className="relative splash-enter">
          <span className="absolute -inset-2 animate-spin rounded-full border-2 border-amber-400/80 border-t-transparent" />
          <Logo size="lg" />
        </div>
        <p className="text-xs font-medium uppercase tracking-[0.3em] text-amber-300/80">
          Carregando...
        </p>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LoginPage />;
  }

  // Autenticado → libera o app. Transição suave de entrada.
  return <div className="splash-enter">{children}</div>;
}
