/**
 * Persistência segura da sessão do usuário.
 *
 * Garantias:
 *  - Usa localStorage (sobrevive a refresh, fechar/abrir aba, reinício do app)
 *  - Toda leitura/escrita é envolvida em try/catch (modo privado, quota cheia)
 *  - JSON.parse é protegido contra dados corrompidos (limpa e retorna null)
 *  - Validação mínima da forma do objeto User
 *  - logout() limpa TUDO relacionado à sessão (token, sessão, flags voláteis)
 */
import type { User } from "./authTypes";

export const SESSION_KEY = "ff_auth_session";
export const TOKEN_KEY = "ff_auth_token";

/* ----------------------------- utilitários ---------------------------- */

function hasLocalStorage(): boolean {
  try {
    return typeof window !== "undefined" && !!window.localStorage;
  } catch {
    return false;
  }
}

/** Validação defensiva: garante que o objeto tem a forma mínima de User. */
function isValidUser(value: unknown): value is User {
  if (!value || typeof value !== "object") return false;
  const u = value as Record<string, unknown>;
  return (
    typeof u.id === "string" &&
    typeof u.email === "string" &&
    typeof u.name === "string" &&
    typeof u.token === "string"
  );
}

/** Remove uma chave de forma segura. */
function safeRemove(key: string) {
  try {
    localStorage.removeItem(key);
  } catch {
    /* ignore */
  }
}

/* -------------------------------- API -------------------------------- */

/**
 * Salva a sessão atual do usuário em localStorage.
 * Retorna true se gravou com sucesso.
 */
export function saveSession(user: User): boolean {
  if (!hasLocalStorage()) return false;
  try {
    const json = JSON.stringify(user);
    localStorage.setItem(SESSION_KEY, json);
    // mantém o token em chave separada (facilita inspeção futura)
    if (user.token) localStorage.setItem(TOKEN_KEY, user.token);
    return true;
  } catch {
    return false;
  }
}

/**
 * Recupera a sessão do usuário do localStorage.
 * Retorna null se não houver sessão, se o JSON estiver corrompido
 * ou se o objeto não passar na validação mínima.
 */
export function getSession(): User | null {
  if (!hasLocalStorage()) return null;

  let raw: string | null = null;
  try {
    raw = localStorage.getItem(SESSION_KEY);
  } catch {
    return null;
  }
  if (!raw) return null;

  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    // Dados corrompidos → limpa e desiste em silêncio.
    safeRemove(SESSION_KEY);
    return null;
  }

  if (!isValidUser(parsed)) {
    safeRemove(SESSION_KEY);
    return null;
  }

  return parsed;
}

/**
 * Encerra a sessão local: remove o usuário ativo e o token.
 * NÃO apaga contas cadastradas localmente nem dados do app
 * (transações, favoritos, etc.) — apenas a sessão.
 */
export function logout(): void {
  if (!hasLocalStorage()) return;
  safeRemove(SESSION_KEY);
  safeRemove(TOKEN_KEY);
}

/**
 * Atalho: existe sessão válida atualmente?
 */
export function hasSession(): boolean {
  return getSession() !== null;
}
