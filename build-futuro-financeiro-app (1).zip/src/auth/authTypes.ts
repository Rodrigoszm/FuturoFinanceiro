export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string; // foto fake (URL ou data)
  token: string; // token local
  createdAt: string;
}

/** Conta registrada (inclui senha — apenas local, NÃO seguro para produção). */
export interface Account extends User {
  password: string;
}

/** Gera um avatar fake determinístico a partir do nome/email. */
export function makeFakeAvatar(seed: string): string {
  const s = encodeURIComponent(seed.trim().toLowerCase() || "user");
  // DiceBear: avatares fake gerados, sem necessidade de upload
  return `https://api.dicebear.com/7.x/initials/svg?seed=${s}&backgroundType=gradientLinear&backgroundColor=10b981,2563eb`;
}

/** Gera um "token" local pseudo-aleatório. */
export function makeToken(): string {
  const rand =
    typeof crypto !== "undefined" && "randomUUID" in crypto
      ? crypto.randomUUID()
      : Math.random().toString(36).slice(2);
  return `local_${rand}_${Date.now().toString(36)}`;
}
