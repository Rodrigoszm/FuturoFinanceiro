import { Component, type ErrorInfo, type ReactNode } from "react";

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

/**
 * ErrorBoundary global.
 * Captura erros de render em qualquer parte da árvore React e mostra
 * uma tela de fallback amigável em vez de uma tela em branco.
 *
 * NÃO interfere com splash, navegação, layout nem AuthContext.
 */
export class ErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false, error: null };

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    // Em produção real isso poderia ser enviado para Sentry/Crashlytics.
    if (typeof console !== "undefined") {
      console.error("[ErrorBoundary]", error, info);
    }
  }

  handleReset = () => {
    this.setState({ hasError: false, error: null });
  };

  handleReload = () => {
    if (typeof window !== "undefined") window.location.reload();
  };

  render() {
    if (!this.state.hasError) return this.props.children;
    if (this.props.fallback) return this.props.fallback;

    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-slate-50 to-emerald-50 p-6">
        <div className="w-full max-w-sm rounded-3xl border border-slate-100 bg-white p-6 text-center shadow-xl">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-rose-50 text-2xl">
            ⚠️
          </div>
          <h1 className="mt-4 text-lg font-extrabold text-slate-900">
            Ops, algo deu errado
          </h1>
          <p className="mt-1 text-sm text-slate-500">
            Não se preocupe — seus dados locais estão seguros.
          </p>
          {this.state.error?.message && (
            <p className="mt-3 max-h-24 overflow-auto rounded-xl bg-slate-50 px-3 py-2 text-left text-xs font-mono text-slate-500">
              {this.state.error.message}
            </p>
          )}
          <div className="mt-5 flex flex-col gap-2">
            <button
              onClick={this.handleReset}
              className="rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-800 px-4 py-2.5 text-sm font-semibold text-white shadow-md transition hover:opacity-95"
            >
              Tentar novamente
            </button>
            <button
              onClick={this.handleReload}
              className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm font-semibold text-slate-600 transition hover:bg-slate-50"
            >
              Recarregar o app
            </button>
          </div>
        </div>
      </div>
    );
  }
}
