interface SectionTitleProps {
  title: string;
  subtitle?: string;
  emoji?: string;
}

export function SectionTitle({ title, subtitle, emoji }: SectionTitleProps) {
  return (
    <div className="mb-5">
      <h2 className="flex items-center gap-2 text-xl font-bold text-slate-900">
        {emoji && <span>{emoji}</span>}
        {title}
      </h2>
      {subtitle && <p className="mt-1 text-sm text-slate-500">{subtitle}</p>}
    </div>
  );
}
