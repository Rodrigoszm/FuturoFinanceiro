import type { ReactElement, SVGProps } from "react";
import type { PageId } from "../../types";

type IconProps = SVGProps<SVGSVGElement>;

const base = {
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
  viewBox: "0 0 24 24",
};

export function HomeIcon(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="M3 10.5 12 3l9 7.5" />
      <path d="M5 9.5V20a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V9.5" />
      <path d="M9.5 21v-6h5v6" />
    </svg>
  );
}

export function LearnIcon(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="M4 5a1 1 0 0 1 1-1h6a2 2 0 0 1 2 2v13a2 2 0 0 0-2-2H5a1 1 0 0 1-1-1Z" />
      <path d="M20 5a1 1 0 0 0-1-1h-6a2 2 0 0 0-2 2v13a2 2 0 0 1 2-2h6a1 1 0 0 0 1-1Z" />
    </svg>
  );
}

export function CalcIcon(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <rect x="5" y="3" width="14" height="18" rx="2" />
      <path d="M8 7h8" />
      <path d="M8 11h.01M12 11h.01M16 11h.01" />
      <path d="M8 15h.01M12 15h.01M16 15v3M8 18h4" />
    </svg>
  );
}

export function CoinsIcon(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <ellipse cx="9" cy="7" rx="6" ry="3" />
      <path d="M3 7v5c0 1.66 2.69 3 6 3" />
      <path d="M3 12v5c0 1.66 2.69 3 6 3" />
      <ellipse cx="15" cy="14" rx="6" ry="3" />
      <path d="M21 14v5c0 1.66-2.69 3-6 3s-6-1.34-6-3" />
    </svg>
  );
}

export function QuizIcon(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <circle cx="12" cy="12" r="9" />
      <path d="M9.5 9a2.5 2.5 0 1 1 3.4 2.3c-.6.3-.9.8-.9 1.4v.3" />
      <path d="M12 17h.01" />
    </svg>
  );
}

export function WalletIcon(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="M3 7a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v0" />
      <rect x="3" y="6" width="18" height="13" rx="2" />
      <path d="M16 12.5h2.5" />
      <circle cx="16.5" cy="12.5" r="0.6" fill="currentColor" stroke="none" />
    </svg>
  );
}

export const NAV_ICONS: Record<PageId, (p: IconProps) => ReactElement> = {
  home: HomeIcon,
  aprender: LearnIcon,
  calculadoras: CalcIcon,
  moedas: CoinsIcon,
  quiz: QuizIcon,
  dinheiro: WalletIcon,
  dicionario: LearnIcon,
  login: HomeIcon,
};
