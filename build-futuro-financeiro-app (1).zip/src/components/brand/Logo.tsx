import { cn } from "../../utils/cn";

interface LogoProps {
  size?: "sm" | "md" | "lg" | "xl";
  variant?: "solid" | "flat"; // solid = dark green tile; flat = transparent
  className?: string;
}

const SIZES: Record<NonNullable<LogoProps["size"]>, { box: string; text: string; radius: string }> = {
  sm: { box: "h-9 w-9", text: "text-base", radius: "rounded-lg" },
  md: { box: "h-12 w-12", text: "text-xl", radius: "rounded-xl" },
  lg: { box: "h-16 w-16", text: "text-2xl", radius: "rounded-2xl" },
  xl: { box: "h-24 w-24", text: "text-4xl", radius: "rounded-3xl" },
};

/**
 * Logo "FF" do Futuro Financeiro.
 * Identidade visual: verde escuro premium + dourado.
 *  - Primeiro F branco
 *  - Segundo F dourado
 */
export function Logo({ size = "md", variant = "solid", className }: LogoProps) {
  const s = SIZES[size];

  return (
    <span
      className={cn(
        "relative inline-flex items-center justify-center overflow-hidden",
        s.box,
        s.radius,
        variant === "solid" &&
          "bg-gradient-to-br from-emerald-900 via-emerald-800 to-emerald-950 shadow-md shadow-emerald-900/30 ring-1 ring-amber-400/30",
        className,
      )}
    >
      {/* subtle gold corner glow */}
      {variant === "solid" && (
        <>
          <span className="pointer-events-none absolute -right-3 -top-3 h-6 w-6 rounded-full bg-amber-400/30 blur-md" />
          <span className="pointer-events-none absolute inset-x-3 bottom-0.5 h-px bg-gradient-to-r from-transparent via-amber-400/70 to-transparent" />
        </>
      )}

      <span
        className={cn(
          "relative flex items-baseline font-extrabold leading-none tracking-tight",
          s.text,
        )}
        style={{ fontFamily: "Georgia, 'Times New Roman', serif" }}
      >
        <span className="text-white drop-shadow-sm">F</span>
        <span
          className="-ml-0.5 bg-gradient-to-b from-amber-200 via-amber-400 to-amber-600 bg-clip-text text-transparent"
          style={{ WebkitTextStroke: "0.5px rgba(180,120,0,0.25)" }}
        >
          F
        </span>
      </span>
    </span>
  );
}

/** Wordmark: logo + "Futuro Financeiro" */
export function LogoWordmark({
  size = "md",
  className,
}: {
  size?: "sm" | "md" | "lg";
  className?: string;
}) {
  return (
    <span className={cn("inline-flex items-center gap-2", className)}>
      <Logo size={size} />
      <span className="leading-tight">
        <span className="block text-sm font-extrabold text-slate-900">Futuro</span>
        <span className="-mt-0.5 block text-xs font-bold text-emerald-700">
          Financeiro
        </span>
      </span>
    </span>
  );
}
