import { useEffect, useRef } from "react";
import { Logo } from "./Logo";

interface SplashProps {
  /** Chamado uma única vez quando a animação termina. */
  onDone?: () => void;
  /** Duração total da exibição, em ms. */
  duration?: number;
}

/**
 * Splash screen segura:
 * - Logo FF centralizado
 * - Animações finitas (sem loop infinito)
 * - Executa apenas UMA vez: dispara onDone somente na primeira chamada
 * - useEffect sem dependências externas (apenas montagem)
 */
export function Splash({ onDone, duration = 1600 }: SplashProps) {
  const finishedRef = useRef(false);

  useEffect(() => {
    // safety net: garante que onDone é chamado mesmo se a animação CSS falhar,
    // mas SEMPRE só uma vez, graças ao ref.
    const id = window.setTimeout(() => {
      if (finishedRef.current) return;
      finishedRef.current = true;
      onDone?.();
    }, duration + 200);

    return () => window.clearTimeout(id);
    // deps vazio de propósito: efeito de montagem único.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function handleEnter() {
    if (finishedRef.current) return;
    finishedRef.current = true;
    onDone?.();
  }

  return (
    <div
      role="status"
      aria-label="Carregando Futuro Financeiro"
      className="fixed inset-0 z-[100] flex flex-col items-center justify-center overflow-hidden bg-gradient-to-br from-emerald-950 via-emerald-900 to-emerald-950 text-white"
    >
      {/* glows decorativos (estáticos, sem animação) */}
      <div className="pointer-events-none absolute left-1/2 top-1/2 h-[420px] w-[420px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-amber-400/15 blur-3xl" />
      <div className="pointer-events-none absolute -left-20 top-1/3 h-40 w-40 rounded-full bg-emerald-400/10 blur-2xl" />
      <div className="pointer-events-none absolute -right-16 bottom-1/3 h-48 w-48 rounded-full bg-amber-300/10 blur-2xl" />

      {/* linha dourada (estática) */}
      <div className="pointer-events-none absolute inset-x-12 top-[42%] h-px bg-gradient-to-r from-transparent via-amber-400/60 to-transparent" />

      {/* logo + título (animação finita 'pop' única) */}
      <div className="relative flex flex-col items-center splash-enter">
        <Logo size="xl" />

        <h1
          className="mt-6 text-3xl font-extrabold tracking-tight text-white"
          style={{ fontFamily: "Georgia, 'Times New Roman', serif" }}
        >
          Futuro{" "}
          <span className="bg-gradient-to-b from-amber-200 via-amber-400 to-amber-600 bg-clip-text text-transparent">
            Financeiro
          </span>
        </h1>

        <p className="mt-2 text-xs font-semibold uppercase tracking-[0.3em] text-amber-300/80">
          Planeje · Controle · Conquiste
        </p>
      </div>

      {/*
        Barra de progresso dourada — animação FINITA (preenche de 0 a 100%
        em `duration`ms e para). Ao terminar dispara onDone via onAnimationEnd.
      */}
      <div className="absolute bottom-16 h-1 w-40 overflow-hidden rounded-full bg-white/10">
        <div
          onAnimationEnd={handleEnter}
          className="h-full rounded-full bg-gradient-to-r from-amber-300 via-amber-400 to-amber-500 splash-progress"
          style={{ animationDuration: `${duration}ms` }}
        />
      </div>
    </div>
  );
}
