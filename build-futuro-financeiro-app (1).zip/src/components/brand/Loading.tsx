import { Logo } from "./Logo";

interface LoadingProps {
  label?: string;
  full?: boolean; // ocupar tela inteira
}

/**
 * Loading premium com logo FF e anel dourado giratório.
 */
export function Loading({ label = "Carregando...", full = false }: LoadingProps) {
  const content = (
    <div className="flex flex-col items-center gap-4">
      <div className="relative">
        {/* gold spinning ring */}
        <span className="absolute -inset-2 animate-spin rounded-full border-2 border-amber-400/80 border-t-transparent" />
        <span className="absolute -inset-2 rounded-full border border-amber-400/20" />
        <Logo size="lg" />
      </div>
      <p className="text-sm font-medium text-emerald-900/70">{label}</p>
    </div>
  );

  if (full) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-white/85 backdrop-blur-sm">
        {content}
      </div>
    );
  }
  return <div className="flex justify-center py-10">{content}</div>;
}

/** Spinner pequeno em linha (sem logo). */
export function Spinner({ className = "" }: { className?: string }) {
  return (
    <span
      className={`inline-block h-4 w-4 animate-spin rounded-full border-2 border-amber-400 border-t-transparent ${className}`}
    />
  );
}
