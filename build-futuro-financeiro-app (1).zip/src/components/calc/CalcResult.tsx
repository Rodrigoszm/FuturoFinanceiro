import type { ReactNode } from "react";

interface CalcResultProps {
  label: string;
  value: string;
  explanation: ReactNode;
}

export function CalcResult({ label, value, explanation }: CalcResultProps) {
  return (
    <div className="mt-4 space-y-3">
      <div className="rounded-2xl bg-gradient-to-br from-emerald-50 to-blue-50 p-4">
        <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
          {label}
        </p>
        <p className="mt-0.5 text-2xl font-extrabold text-emerald-600">{value}</p>
      </div>
      <div className="flex gap-2 rounded-xl bg-slate-50 p-3 text-xs leading-relaxed text-slate-600">
        <span>💡</span>
        <p>{explanation}</p>
      </div>
    </div>
  );
}
