import { useState } from "react";
import { Card } from "../ui/Card";
import { Field } from "../ui/Field";
import { CalcResult } from "./CalcResult";

/* ------------------------------ helpers ------------------------------ */

function brl(n: number) {
  if (!isFinite(n)) return "—";
  return n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

function num(v: string) {
  return Number(v.replace(",", ".")) || 0;
}

interface CalcShellProps {
  emoji: string;
  title: string;
  desc: string;
  gradient: string;
  children: React.ReactNode;
}

function CalcShell({ emoji, title, desc, gradient, children }: CalcShellProps) {
  return (
    <Card>
      <div className="flex items-center gap-3">
        <span
          className={`flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br ${gradient} text-xl text-white shadow-md`}
        >
          {emoji}
        </span>
        <div>
          <h3 className="font-bold text-slate-900">{title}</h3>
          <p className="text-xs text-slate-500">{desc}</p>
        </div>
      </div>
      <div className="mt-4">{children}</div>
    </Card>
  );
}

/* --------------------------- 1. Porcentagem -------------------------- */

export function PercentCalc() {
  const [percent, setPercent] = useState("15");
  const [value, setValue] = useState("200");

  const p = num(percent);
  const v = num(value);
  const result = (v * p) / 100;

  return (
    <CalcShell
      emoji="％"
      title="Porcentagem"
      desc="Quanto é X% de um valor"
      gradient="from-emerald-500 to-teal-600"
    >
      <div className="grid grid-cols-2 gap-3">
        <Field label="Porcentagem" value={percent} onChange={setPercent} suffix="%" />
        <Field label="Sobre o valor" value={value} onChange={setValue} suffix="R$" />
      </div>
      <CalcResult
        label={`${p}% de ${brl(v)}`}
        value={brl(result)}
        explanation={
          <>
            Para calcular, multiplicamos {brl(v)} × {p} e dividimos por 100. Ex.:
            uma gorjeta de {p}% nesse valor seria {brl(result)}.
          </>
        }
      />
    </CalcShell>
  );
}

/* ----------------------------- 2. Desconto --------------------------- */

export function DiscountCalc() {
  const [price, setPrice] = useState("2000");
  const [discount, setDiscount] = useState("15");

  const pr = num(price);
  const d = num(discount);
  const saved = (pr * d) / 100;
  const final = pr - saved;

  return (
    <CalcShell
      emoji="🏷️"
      title="Desconto"
      desc="Preço final com desconto"
      gradient="from-rose-500 to-pink-600"
    >
      <div className="grid grid-cols-2 gap-3">
        <Field label="Preço original" value={price} onChange={setPrice} suffix="R$" />
        <Field label="Desconto" value={discount} onChange={setDiscount} suffix="%" />
      </div>
      <CalcResult
        label="Você paga"
        value={brl(final)}
        explanation={
          <>
            Com {d}% de desconto você economiza <b>{brl(saved)}</b>. O preço cai
            de {brl(pr)} para {brl(final)}.
          </>
        }
      />
    </CalcShell>
  );
}

/* -------------------------- 3. Juros Simples ------------------------- */

export function SimpleInterestCalc() {
  const [capital, setCapital] = useState("1000");
  const [rate, setRate] = useState("2");
  const [months, setMonths] = useState("5");

  const c = num(capital);
  const r = num(rate) / 100;
  const t = num(months);
  const interest = c * r * t;
  const total = c + interest;

  return (
    <CalcShell
      emoji="➕"
      title="Juros Simples"
      desc="Juros sempre sobre o valor inicial"
      gradient="from-blue-500 to-indigo-600"
    >
      <div className="grid grid-cols-3 gap-2">
        <Field label="Capital" value={capital} onChange={setCapital} suffix="R$" />
        <Field label="Taxa/mês" value={rate} onChange={setRate} suffix="%" />
        <Field label="Meses" value={months} onChange={setMonths} />
      </div>
      <CalcResult
        label="Total a pagar/receber"
        value={brl(total)}
        explanation={
          <>
            Juros = capital × taxa × tempo = {brl(c)} × {num(rate)}% × {t} meses ={" "}
            <b>{brl(interest)}</b>. O valor não rende sobre os próprios juros.
          </>
        }
      />
    </CalcShell>
  );
}

/* ------------------------- 4. Juros Compostos ------------------------ */

export function CompoundInterestCalc() {
  const [initial, setInitial] = useState("1000");
  const [monthly, setMonthly] = useState("200");
  const [rate, setRate] = useState("0.9");
  const [months, setMonths] = useState("24");

  const i = num(initial);
  const m = num(monthly);
  const r = num(rate) / 100;
  const n = Math.max(0, Math.floor(num(months)));

  let total = i;
  for (let k = 0; k < n; k++) total = total * (1 + r) + m;
  const invested = i + m * n;
  const earnings = total - invested;

  return (
    <CalcShell
      emoji="📈"
      title="Juros Compostos"
      desc="Juros sobre juros (efeito bola de neve)"
      gradient="from-teal-500 to-emerald-600"
    >
      <div className="grid grid-cols-2 gap-3">
        <Field label="Valor inicial" value={initial} onChange={setInitial} suffix="R$" />
        <Field label="Aporte mensal" value={monthly} onChange={setMonthly} suffix="R$" />
        <Field label="Taxa ao mês" value={rate} onChange={setRate} suffix="%" />
        <Field label="Período" value={months} onChange={setMonths} suffix="meses" />
      </div>
      <CalcResult
        label="Valor final estimado"
        value={brl(total)}
        explanation={
          <>
            Você investe <b>{brl(invested)}</b> e ganha <b>{brl(earnings)}</b> em
            juros. Quanto maior o tempo, maior o efeito bola de neve.
          </>
        }
      />
    </CalcShell>
  );
}

/* ----------------------------- 5. Parcelas --------------------------- */

export function InstallmentCalc() {
  const [total, setTotal] = useState("3000");
  const [count, setCount] = useState("12");
  const [rate, setRate] = useState("1.99");

  const pv = num(total);
  const n = Math.max(1, Math.floor(num(count)));
  const r = num(rate) / 100;

  // Tabela Price: parcela = PV * r / (1 - (1+r)^-n)
  let parcela: number;
  if (r === 0) parcela = pv / n;
  else parcela = (pv * r) / (1 - Math.pow(1 + r, -n));

  const totalPago = parcela * n;
  const jurosTotais = totalPago - pv;

  return (
    <CalcShell
      emoji="🧾"
      title="Parcelas"
      desc="Valor da parcela e juros totais"
      gradient="from-amber-500 to-orange-600"
    >
      <div className="grid grid-cols-3 gap-2">
        <Field label="Valor total" value={total} onChange={setTotal} suffix="R$" />
        <Field label="Parcelas" value={count} onChange={setCount} suffix="x" />
        <Field label="Juros/mês" value={rate} onChange={setRate} suffix="%" />
      </div>
      <CalcResult
        label={`Parcela (${n}x)`}
        value={brl(parcela)}
        explanation={
          <>
            Total pago: <b>{brl(totalPago)}</b> — sendo <b>{brl(jurosTotais)}</b>{" "}
            só de juros. Para 0% de juros, deixe a taxa em 0 e a parcela será o
            valor dividido igualmente.
          </>
        }
      />
    </CalcShell>
  );
}
