import type { PageId } from "../../types";
import { NAV_ICONS } from "../icons/NavIcons";
import { cn } from "../../utils/cn";

interface TabItem {
  id: PageId;
  label: string;
}

const TABS: TabItem[] = [
  { id: "home", label: "Início" },
  { id: "aprender", label: "Aprender" },
  { id: "calculadoras", label: "Calcular" },
  { id: "moedas", label: "Moedas" },
  { id: "quiz", label: "Quiz" },
  { id: "dinheiro", label: "Dinheiro" },
];

interface MobileTabBarProps {
  current: PageId;
  onNavigate: (page: PageId) => void;
}

export function MobileTabBar({ current, onNavigate }: MobileTabBarProps) {
  return (
    <div className="fixed inset-x-0 bottom-0 z-40 md:hidden">
      {/* fade behind bar for content scroll */}
      <div className="pointer-events-none h-6 bg-gradient-to-t from-white to-transparent" />

      <nav
        className="border-t border-slate-100 bg-white/85 backdrop-blur-xl shadow-[0_-8px_30px_-12px_rgba(2,44,34,0.18)]"
        style={{ paddingBottom: "max(env(safe-area-inset-bottom), 0.25rem)" }}
        aria-label="Navegação principal"
      >
        <ul className="mx-auto flex max-w-md items-stretch justify-between px-1.5 pt-1.5">
          {TABS.map((tab) => {
            const Icon = NAV_ICONS[tab.id];
            const active = current === tab.id;
            return (
              <li key={tab.id} className="flex-1">
                <button
                  type="button"
                  onClick={() => onNavigate(tab.id)}
                  aria-current={active ? "page" : undefined}
                  className="group relative flex w-full flex-col items-center gap-1 rounded-2xl px-0.5 py-1.5 outline-none"
                >
                  {/* active indicator dot on top */}
                  <span
                    className={cn(
                      "absolute -top-[7px] h-1 w-7 rounded-full bg-gradient-to-r from-emerald-500 to-blue-600 transition-all duration-300",
                      active ? "opacity-100 scale-100" : "opacity-0 scale-50",
                    )}
                  />

                  {/* icon pill */}
                  <span
                    className={cn(
                      "flex h-9 w-12 items-center justify-center rounded-xl transition-all duration-300",
                      active
                        ? "bg-gradient-to-br from-emerald-500 to-blue-600 text-white shadow-md shadow-emerald-300/50 -translate-y-0.5"
                        : "text-slate-400 group-active:bg-slate-100 group-active:text-slate-600",
                    )}
                  >
                    <Icon className="h-[22px] w-[22px]" />
                  </span>

                  <span
                    className={cn(
                      "text-[10px] font-semibold leading-none transition-colors duration-300",
                      active ? "text-emerald-700" : "text-slate-400",
                    )}
                  >
                    {tab.label}
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      </nav>
    </div>
  );
}
