import { NAV_ITEMS } from "../../nav";
import type { PageId } from "../../types";
import { cn } from "../../utils/cn";

interface BottomNavProps {
  current: PageId;
  onNavigate: (page: PageId) => void;
}

export function BottomNav({ current, onNavigate }: BottomNavProps) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 border-t border-slate-100 bg-white/90 backdrop-blur-md">
      <div className="mx-auto flex max-w-md items-center justify-between px-2 py-1.5">
        {NAV_ITEMS.map((item) => {
          const active = current === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={cn(
                "flex flex-1 flex-col items-center gap-0.5 rounded-xl px-1 py-1.5 text-[10px] font-medium transition",
                active ? "text-emerald-600" : "text-slate-400 hover:text-slate-600",
              )}
            >
              <span className={cn("text-lg transition", active && "scale-110")}>
                {item.icon}
              </span>
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
