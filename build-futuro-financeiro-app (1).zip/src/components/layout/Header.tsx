import type { PageId } from "../../types";
import { useAuth } from "../../auth/AuthContext";
import { Logo } from "../brand/Logo";

interface HeaderProps {
  onNavigate: (page: PageId) => void;
}

export function Header({ onNavigate }: HeaderProps) {
  const { user, isAuthenticated } = useAuth();
  return (
    <header className="sticky top-0 z-30 border-b border-slate-100 bg-white/80 backdrop-blur-md">
      <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-3">
        <button
          onClick={() => onNavigate("home")}
          className="flex items-center gap-2"
        >
          <Logo size="sm" />
          <div
            className="text-left leading-tight"
            style={{ fontFamily: "Georgia, 'Times New Roman', serif" }}
          >
            <p className="text-sm font-extrabold text-emerald-950">Futuro</p>
            <p className="-mt-0.5 text-xs font-bold text-amber-600">
              Financeiro
            </p>
          </div>
        </button>

        {/* Desktop nav */}
        <nav className="hidden items-center gap-1 md:flex">
          {[
            { id: "aprender", label: "Aprender" },
            { id: "calculadoras", label: "Calculadoras" },
            { id: "moedas", label: "Moedas" },
            { id: "dicionario", label: "Dicionário" },
            { id: "quiz", label: "Quiz" },
            { id: "dinheiro", label: "Meu Dinheiro" },
          ].map((i) => (
            <button
              key={i.id}
              onClick={() => onNavigate(i.id as PageId)}
              className="rounded-lg px-3 py-2 text-sm font-medium text-slate-600 transition hover:bg-slate-50 hover:text-slate-900"
            >
              {i.label}
            </button>
          ))}
        </nav>

        {isAuthenticated && user ? (
          <button
            onClick={() => onNavigate("login")}
            className="flex items-center gap-2 rounded-full border border-slate-200 bg-white py-1 pl-1 pr-3 transition hover:bg-slate-50"
          >
            <img
              src={user.avatar}
              alt={user.name}
              className="h-7 w-7 rounded-full"
            />
            <span className="hidden text-sm font-semibold text-slate-700 sm:inline">
              {user.name.split(" ")[0]}
            </span>
          </button>
        ) : (
          <button
            onClick={() => onNavigate("login")}
            className="rounded-xl bg-gradient-to-r from-emerald-500 to-blue-600 px-4 py-2 text-sm font-semibold text-white shadow-md shadow-emerald-200 transition hover:opacity-90"
          >
            Entrar
          </button>
        )}
      </div>
    </header>
  );
}
