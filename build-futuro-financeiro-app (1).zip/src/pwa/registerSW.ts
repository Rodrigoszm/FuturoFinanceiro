/**
 * Registro do service worker do Futuro Financeiro.
 * Seguro:
 *  - Só registra em produção (evita problemas com HMR do Vite no dev)
 *  - Só registra se o navegador suportar
 *  - Não quebra o app se o registro falhar
 */
export function registerSW() {
  if (typeof window === "undefined") return;
  if (!("serviceWorker" in navigator)) return;
  // Só em produção (evita conflitos com HMR do Vite no dev)
  const meta = import.meta as unknown as { env?: { PROD?: boolean } };
  if (!meta.env?.PROD) return;

  window.addEventListener("load", () => {
    // Usa caminho relativo para funcionar tanto na raiz quanto em subpastas
    const swUrl = new URL("sw.js", document.baseURI).toString();
    navigator.serviceWorker.register(swUrl).catch(() => {
      /* falha silenciosa — app continua funcionando normalmente */
    });
  });
}
