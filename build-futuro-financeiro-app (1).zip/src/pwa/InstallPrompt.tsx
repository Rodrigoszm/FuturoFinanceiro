/**
 * Banner de instalação PWA — Futuro Financeiro.
 *
 * Regras:
 *  - Aparece suavemente no Chrome Android quando o navegador
 *    dispara `beforeinstallprompt`.
 *  - Aparece no iOS Safari (que não suporta o evento) com instruções
 *    de "Adicionar à Tela Inicial".
 *  - NÃO aparece se o app já estiver instalado / em standalone.
 *  - NÃO aparece se o usuário dispensou antes (lembrado em localStorage).
 *  - Animação leve e FINITA (sem loops infinitos).
 *
 * Não modifica AuthContext, LoginPage, navegação ou páginas existentes.
 */
import { useEffect, useState } from "react";
import { Logo } from "../components/brand/Logo";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

const DISMISS_KEY = "ff_pwa_dismissed";
const SHOW_DELAY_MS = 1200; // entrada suave após carregar

/* ------------------------- detection helpers ------------------------- */

function isStandalone(): boolean {
  if (typeof window === "undefined") return false;
  try {
    if (window.matchMedia?.("(display-mode: standalone)").matches) return true;
    const nav = window.navigator as Navigator & { standalone?: boolean };
    return Boolean(nav.standalone);
  } catch {
    return false;
  }
}

function isIOS(): boolean {
  if (typeof navigator === "undefined") return false;
  const ua = navigator.userAgent || "";
  // iPad em iOS 13+ se reporta como Mac com touch
  const isIPad = /Macintosh/.test(ua) && "ontouchend" in document;
  return /iPad|iPhone|iPod/.test(ua) || isIPad;
}

function isDismissed(): boolean {
  try {
    return localStorage.getItem(DISMISS_KEY) === "1";
  } catch {
    return false;
  }
}

/* ------------------------------ component ----------------------------- */

export function InstallPrompt() {
  const [evt, setEvt] = useState<BeforeInstallPromptEvent | null>(null);
  const [visible, setVisible] = useState(false);
  const [closing, setClosing] = useState(false);
  const [showIOSHelp, setShowIOSHelp] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (isStandalone()) return; // já instalado
    if (isDismissed()) return;

    let cleanup: Array<() => void> = [];
    let mounted = true;

    // 1) Chrome / Android — escuta beforeinstallprompt
    const onBefore = (e: Event) => {
      e.preventDefault();
      if (!mounted) return;
      setEvt(e as BeforeInstallPromptEvent);
      // delay para entrada suave
      const t = window.setTimeout(() => mounted && setVisible(true), SHOW_DELAY_MS);
      cleanup.push(() => window.clearTimeout(t));
    };

    const onInstalled = () => {
      setVisible(false);
      setEvt(null);
      try {
        localStorage.setItem(DISMISS_KEY, "1");
      } catch {
        /* ignore */
      }
    };

    window.addEventListener("beforeinstallprompt", onBefore);
    window.addEventListener("appinstalled", onInstalled);
    cleanup.push(() => window.removeEventListener("beforeinstallprompt", onBefore));
    cleanup.push(() => window.removeEventListener("appinstalled", onInstalled));

    // 2) iOS Safari — sem beforeinstallprompt. Mostramos instruções.
    if (isIOS()) {
      const t = window.setTimeout(() => {
        if (mounted) setVisible(true);
      }, SHOW_DELAY_MS);
      cleanup.push(() => window.clearTimeout(t));
    }

    return () => {
      mounted = false;
      cleanup.forEach((fn) => fn());
      cleanup = [];
    };
    // efeito de montagem único
  }, []);

  if (!visible) return null;

  function close(remember = true) {
    if (remember) {
      try {
        localStorage.setItem(DISMISS_KEY, "1");
      } catch {
        /* ignore */
      }
    }
    // animação de saída finita
    setClosing(true);
    window.setTimeout(() => {
      setVisible(false);
      setClosing(false);
    }, 250);
  }

  async function install() {
    // Caminho Android/Chrome
    if (evt) {
      try {
        await evt.prompt();
        await evt.userChoice;
      } catch {
        /* usuário cancelou — apenas fecha */
      }
      setEvt(null);
      close(false);
      return;
    }
    // iOS: não há API — mostra instruções
    if (isIOS()) {
      setShowIOSHelp(true);
    }
  }

  return (
    <div
      className="fixed inset-0 z-[60] flex items-end justify-center sm:items-center"
      role="dialog"
      aria-modal="true"
      aria-label="Instalar Futuro Financeiro"
    >
      {/* overlay */}
      <div
        onClick={() => close(false)}
        className={`absolute inset-0 bg-slate-900/50 backdrop-blur-sm transition-opacity duration-250 ${
          closing ? "opacity-0" : "opacity-100"
        }`}
      />

      {/* banner */}
      <div
        className={`relative w-full max-w-sm overflow-hidden rounded-t-3xl border border-amber-400/20 bg-gradient-to-br from-emerald-950 via-emerald-900 to-emerald-950 px-5 pb-6 pt-5 text-white shadow-2xl shadow-emerald-950/40 sm:mx-4 sm:rounded-3xl ${
          closing ? "install-leave" : "install-enter"
        }`}
      >
        {/* glows decorativos (estáticos) */}
        <div className="pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full bg-amber-400/15 blur-2xl" />
        <div className="pointer-events-none absolute -left-10 bottom-0 h-24 w-24 rounded-full bg-emerald-400/10 blur-2xl" />
        <div className="pointer-events-none absolute inset-x-6 bottom-0 h-px bg-gradient-to-r from-transparent via-amber-400/40 to-transparent" />

        {/* drag handle (mobile) */}
        <div className="mb-2 flex justify-center sm:hidden">
          <span className="h-1.5 w-10 rounded-full bg-white/15" />
        </div>

        {/* close X */}
        <button
          type="button"
          onClick={() => close(true)}
          aria-label="Fechar"
          className="absolute right-3 top-3 flex h-8 w-8 items-center justify-center rounded-full bg-white/10 text-sm text-white/80 transition hover:bg-white/15 active:scale-95"
        >
          ✕
        </button>

        {!showIOSHelp ? (
          <>
            {/* Logo */}
            <div className="flex justify-center pt-1">
              <Logo size="lg" />
            </div>

            {/* Textos */}
            <h2
              className="mt-4 text-center text-xl font-extrabold tracking-tight"
              style={{ fontFamily: "Georgia, 'Times New Roman', serif" }}
            >
              Instale o{" "}
              <span className="bg-gradient-to-b from-amber-200 via-amber-400 to-amber-600 bg-clip-text text-transparent">
                Futuro Financeiro
              </span>
            </h2>
            <p className="mt-2 text-center text-sm text-white/70">
              Tenha acesso rápido à sua educação financeira.
            </p>

            {/* Vantagens rápidas */}
            <ul className="mx-auto mt-4 grid max-w-[260px] grid-cols-3 gap-2 text-center text-[10px] font-semibold uppercase tracking-wider text-amber-300/80">
              <li className="rounded-lg bg-white/5 py-2">📲 Tela cheia</li>
              <li className="rounded-lg bg-white/5 py-2">⚡ Mais rápido</li>
              <li className="rounded-lg bg-white/5 py-2">🔒 Offline</li>
            </ul>

            {/* Botões */}
            <div className="mt-5 space-y-2.5">
              <button
                type="button"
                onClick={install}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-amber-400 via-amber-400 to-amber-500 px-4 py-3 text-sm font-bold text-emerald-950 shadow-lg shadow-amber-500/20 transition hover:brightness-110 active:scale-[0.99]"
              >
                📥 Instalar App
              </button>
              <button
                type="button"
                onClick={() => close(true)}
                className="w-full rounded-xl border border-white/15 bg-transparent px-4 py-3 text-sm font-semibold text-white/80 transition hover:bg-white/5 active:scale-[0.99]"
              >
                Agora não
              </button>
            </div>
          </>
        ) : (
          /* Instruções iOS */
          <div className="pt-1 text-center">
            <div className="flex justify-center">
              <Logo size="md" />
            </div>
            <h2 className="mt-4 text-lg font-extrabold">Instale no iPhone</h2>
            <p className="mt-2 text-sm text-white/70">
              Para adicionar à tela inicial:
            </p>
            <ol className="mx-auto mt-4 space-y-2 text-left text-sm text-white/90">
              <li className="flex items-start gap-2 rounded-xl bg-white/5 p-3">
                <span className="font-bold text-amber-300">1.</span>
                <span>
                  Toque em <b>Compartilhar</b>{" "}
                  <span className="rounded bg-white/10 px-1.5 py-0.5 text-xs">
                    􀈂
                  </span>{" "}
                  na barra inferior do Safari.
                </span>
              </li>
              <li className="flex items-start gap-2 rounded-xl bg-white/5 p-3">
                <span className="font-bold text-amber-300">2.</span>
                <span>
                  Escolha <b>Adicionar à Tela de Início</b>.
                </span>
              </li>
              <li className="flex items-start gap-2 rounded-xl bg-white/5 p-3">
                <span className="font-bold text-amber-300">3.</span>
                <span>
                  Toque em <b>Adicionar</b> no canto superior direito.
                </span>
              </li>
            </ol>
            <button
              type="button"
              onClick={() => close(true)}
              className="mt-5 w-full rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 px-4 py-3 text-sm font-bold text-emerald-950 transition hover:brightness-110 active:scale-[0.99]"
            >
              Entendi
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
