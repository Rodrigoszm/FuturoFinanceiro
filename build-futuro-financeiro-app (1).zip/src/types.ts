export type PageId =
  | "home"
  | "aprender"
  | "calculadoras"
  | "moedas"
  | "quiz"
  | "dinheiro"
  | "dicionario"
  | "login";

export interface NavItem {
  id: PageId;
  label: string;
  icon: string;
}
