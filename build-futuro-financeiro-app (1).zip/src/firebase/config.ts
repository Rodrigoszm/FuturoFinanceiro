/**
 * Inicialização segura do Firebase.
 *
 * Regras de segurança:
 *  - Singleton: usa getApps() para inicializar apenas UMA vez (resistente a HMR).
 *  - try/catch: se a inicialização falhar (config ausente, rede ruim, etc.)
 *    expomos firebaseReady = false e o app cai automaticamente no modo local.
 *  - Sem chamadas síncronas que possam quebrar o bundle se as envs faltarem.
 */
import { initializeApp, getApps, getApp, type FirebaseApp } from "firebase/app";
import { getAuth, type Auth } from "firebase/auth";
import { getFirestore, type Firestore } from "firebase/firestore";

interface FFEnv {
  VITE_FIREBASE_API_KEY?: string;
  VITE_FIREBASE_AUTH_DOMAIN?: string;
  VITE_FIREBASE_PROJECT_ID?: string;
  VITE_FIREBASE_STORAGE_BUCKET?: string;
  VITE_FIREBASE_MESSAGING_SENDER_ID?: string;
  VITE_FIREBASE_APP_ID?: string;
}

const env = (import.meta as unknown as { env?: FFEnv }).env ?? {};

const firebaseConfig = {
  apiKey: env.VITE_FIREBASE_API_KEY,
  authDomain: env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: env.VITE_FIREBASE_APP_ID,
};

function hasMinimalConfig() {
  return Boolean(firebaseConfig.apiKey && firebaseConfig.projectId);
}

let app: FirebaseApp | null = null;
let authInstance: Auth | null = null;
let dbInstance: Firestore | null = null;
let initError: string | null = null;

function init() {
  if (app) return; // já inicializado nesta sessão
  if (!hasMinimalConfig()) {
    initError = "Configuração do Firebase ausente (variáveis VITE_FIREBASE_*).";
    return;
  }
  try {
    app = getApps().length ? getApp() : initializeApp(firebaseConfig);
    authInstance = getAuth(app);
    dbInstance = getFirestore(app);
  } catch (err) {
    initError = err instanceof Error ? err.message : "Falha ao iniciar Firebase";
    app = null;
    authInstance = null;
    dbInstance = null;
  }
}

// Inicializa de forma preguiçosa porém apenas uma vez por módulo (singleton).
init();

export const firebaseReady = app !== null;
export const firebaseInitError = initError;
export const firebaseAuth = authInstance;
export const firebaseDb = dbInstance;
