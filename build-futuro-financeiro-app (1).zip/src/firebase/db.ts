/**
 * Helpers seguros para Firestore.
 * - Cada função verifica se o Firebase está pronto
 * - Erros são capturados; retorna { ok, data?, error? }
 * - Documentos são escopados por uid do usuário
 *
 * Estrutura sugerida:
 *   users/{uid}/data/{docId}     ← dados livres (ex.: settings, transactions...)
 */
import {
  doc,
  getDoc,
  setDoc,
  serverTimestamp,
} from "firebase/firestore";
import { firebaseDb, firebaseReady } from "./config";

export interface DbResult<T = unknown> {
  ok: boolean;
  data?: T;
  error?: string;
}

export async function saveDoc<T extends Record<string, unknown>>(
  uid: string,
  docId: string,
  value: T,
): Promise<DbResult> {
  if (!firebaseReady || !firebaseDb) {
    return { ok: false, error: "Firestore indisponível" };
  }
  try {
    await setDoc(
      doc(firebaseDb, "users", uid, "data", docId),
      { ...value, updatedAt: serverTimestamp() },
      { merge: true },
    );
    return { ok: true };
  } catch (err) {
    return {
      ok: false,
      error: err instanceof Error ? err.message : "Falha ao salvar",
    };
  }
}

export async function loadDoc<T>(
  uid: string,
  docId: string,
): Promise<DbResult<T>> {
  if (!firebaseReady || !firebaseDb) {
    return { ok: false, error: "Firestore indisponível" };
  }
  try {
    const snap = await getDoc(doc(firebaseDb, "users", uid, "data", docId));
    return { ok: true, data: snap.exists() ? (snap.data() as T) : undefined };
  } catch (err) {
    return {
      ok: false,
      error: err instanceof Error ? err.message : "Falha ao carregar",
    };
  }
}
