/**
 * Wrapper seguro do Firebase Auth.
 * Todas as funções retornam { ok, error?, data? } — nunca lançam exceções
 * que possam quebrar o componente que chamar.
 */
import {
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut,
  updateProfile,
  type User as FbUser,
} from "firebase/auth";
import { firebaseAuth, firebaseReady } from "./config";
import { makeFakeAvatar, makeToken, type User } from "../auth/authTypes";

export interface AuthOpResult {
  ok: boolean;
  user?: User;
  error?: string;
}

function fbToUser(u: FbUser): User {
  const displayName = u.displayName || (u.email ? u.email.split("@")[0] : "Usuário");
  return {
    id: u.uid,
    name: displayName,
    email: u.email ?? "",
    avatar: u.photoURL || makeFakeAvatar(displayName),
    token: makeToken(), // token local de sessão (não é o ID token do Firebase)
    createdAt: u.metadata?.creationTime ?? new Date().toISOString(),
  };
}

function friendlyError(code: string | undefined, fallback: string) {
  switch (code) {
    case "auth/invalid-credential":
    case "auth/wrong-password":
      return "E-mail ou senha incorretos.";
    case "auth/user-not-found":
      return "E-mail não cadastrado.";
    case "auth/email-already-in-use":
      return "Este e-mail já está cadastrado.";
    case "auth/invalid-email":
      return "E-mail inválido.";
    case "auth/weak-password":
      return "A senha precisa de ao menos 6 caracteres.";
    case "auth/network-request-failed":
      return "Sem conexão com a internet.";
    default:
      return fallback;
  }
}

export async function fbSignup(
  name: string,
  email: string,
  password: string,
): Promise<AuthOpResult> {
  if (!firebaseReady || !firebaseAuth) {
    return { ok: false, error: "Firebase indisponível" };
  }
  try {
    const cred = await createUserWithEmailAndPassword(
      firebaseAuth,
      email.trim(),
      password,
    );
    if (cred.user && name.trim()) {
      try {
        await updateProfile(cred.user, { displayName: name.trim() });
      } catch {
        /* ignora falha de profile update */
      }
    }
    return { ok: true, user: fbToUser(cred.user) };
  } catch (err) {
    const code = (err as { code?: string })?.code;
    return { ok: false, error: friendlyError(code, "Não foi possível cadastrar.") };
  }
}

export async function fbLogin(
  email: string,
  password: string,
): Promise<AuthOpResult> {
  if (!firebaseReady || !firebaseAuth) {
    return { ok: false, error: "Firebase indisponível" };
  }
  try {
    const cred = await signInWithEmailAndPassword(
      firebaseAuth,
      email.trim(),
      password,
    );
    return { ok: true, user: fbToUser(cred.user) };
  } catch (err) {
    const code = (err as { code?: string })?.code;
    return { ok: false, error: friendlyError(code, "Não foi possível entrar.") };
  }
}

export async function fbLogout(): Promise<void> {
  if (!firebaseReady || !firebaseAuth) return;
  try {
    await signOut(firebaseAuth);
  } catch {
    /* ignora */
  }
}

/**
 * Observa mudanças de auth. Retorna função de unsubscribe (ou no-op).
 */
export function fbOnAuthChange(
  cb: (user: User | null) => void,
): () => void {
  if (!firebaseReady || !firebaseAuth) return () => {};
  try {
    return onAuthStateChanged(firebaseAuth, (u) => {
      cb(u ? fbToUser(u) : null);
    });
  } catch {
    return () => {};
  }
}
