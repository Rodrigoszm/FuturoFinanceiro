import { useEffect, useRef, useState } from "react";
import type { PageId } from "./types";
import { Header } from "./components/layout/Header";
import { MobileTabBar } from "./components/layout/MobileTabBar";
import { Splash } from "./components/brand/Splash";
import { InstallPrompt } from "./pwa/InstallPrompt";
import { AuthGate } from "./auth/AuthGate";
import { Home } from "./pages/Home";
import { Aprender } from "./pages/Aprender";
import { Calculadoras } from "./pages/Calculadoras";
import { Moedas } from "./pages/Moedas";
import { Quiz } from "./pages/Quiz";
import { MeuDinheiro } from "./pages/MeuDinheiro";
import { Dicionario } from "./pages/Dicionario";
import { Login } from "./pages/Login";

const SPLASH_KEY = "ff_splash_seen";

export default function App() {
  const [page, setPage] = useState<PageId>("home");

  // Mostra a splash apenas na primeira vez da sessão.
  // Lê do sessionStorage no init para evitar re-renders desnecessários.
  const [booting, setBooting] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem(SPLASH_KEY) !== "1";
    } catch {
      return true;
    }
  });

  const navigate = (p: PageId) => {
    setPage(p);
  };

  useEffect(() => {
    window.scrollTo({ top: 0 });
  }, [page]);

  // Handler estável: roda no máximo uma vez.
  const finishedRef = useRef(false);
  const finishSplash = () => {
    if (finishedRef.current) return;
    finishedRef.current = true;
    try {
      sessionStorage.setItem(SPLASH_KEY, "1");
    } catch {
      /* ignore */
    }
    setBooting(false);
  };

  if (booting) return <Splash onDone={finishSplash} />;

  function renderPage() {
    switch (page) {
      case "home":
        return <Home onNavigate={navigate} />;
      case "aprender":
        return <Aprender />;
      case "calculadoras":
        return <Calculadoras />;
      case "moedas":
        return <Moedas />;
      case "quiz":
        return <Quiz />;
      case "dinheiro":
        return <MeuDinheiro />;
      case "dicionario":
        return <Dicionario />;
      case "login":
        return <Login onNavigate={navigate} />;
      default:
        return <Home onNavigate={navigate} />;
    }
  }

  return (
    <AuthGate>
      <div className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-emerald-50/40 text-slate-900">
        <Header onNavigate={navigate} />

        <main className="mx-auto max-w-5xl px-4 pb-28 pt-6 md:pb-12">
          {renderPage()}
        </main>

        <MobileTabBar current={page} onNavigate={navigate} />
        <InstallPrompt />
      </div>
    </AuthGate>
  );
}
