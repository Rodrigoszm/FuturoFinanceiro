export interface AssetQuote {
  code: string; // USD, EUR, BTC...
  name: string;
  emoji: string;
  value: number; // bid em BRL
  pctChange: number; // variação %
  high: number;
  low: number;
  updated: string; // create_date
}

interface RawQuote {
  code: string;
  codein: string;
  name: string;
  high: string;
  low: string;
  varBid: string;
  pctChange: string;
  bid: string;
  ask: string;
  timestamp: string;
  create_date: string;
}

const ASSETS: { pair: string; key: string; emoji: string; label: string }[] = [
  { pair: "USD-BRL", key: "USDBRL", emoji: "💵", label: "Dólar" },
  { pair: "EUR-BRL", key: "EURBRL", emoji: "💶", label: "Euro" },
  { pair: "BTC-BRL", key: "BTCBRL", emoji: "₿", label: "Bitcoin" },
  { pair: "ETH-BRL", key: "ETHBRL", emoji: "Ξ", label: "Ethereum" },
  { pair: "XAU-BRL", key: "XAUBRL", emoji: "🥇", label: "Ouro (oz)" },
];

const ENDPOINT =
  "https://economia.awesomeapi.com.br/json/last/" +
  ASSETS.map((a) => a.pair).join(",");

export async function fetchQuotes(): Promise<AssetQuote[]> {
  const res = await fetch(ENDPOINT);
  if (!res.ok) throw new Error("Falha ao buscar cotações");
  const data: Record<string, RawQuote> = await res.json();

  return ASSETS.map((a) => {
    const raw = data[a.key];
    return {
      code: a.label,
      name: raw?.name ?? a.label,
      emoji: a.emoji,
      value: Number(raw?.bid ?? 0),
      pctChange: Number(raw?.pctChange ?? 0),
      high: Number(raw?.high ?? 0),
      low: Number(raw?.low ?? 0),
      updated: raw?.create_date ?? "",
    };
  });
}
