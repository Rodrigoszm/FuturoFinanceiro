export type TermCategory = "renda-fixa" | "investimentos" | "cripto" | "impostos";

export interface Term {
  id: string;
  abbr: string;
  name: string;
  category: TermCategory;
  short: string;
  full: string;
  example: string;
}

export const TERM_CATEGORIES: { id: TermCategory; label: string; emoji: string }[] = [
  { id: "renda-fixa", label: "Renda Fixa", emoji: "🏦" },
  { id: "investimentos", label: "Investimentos", emoji: "📊" },
  { id: "cripto", label: "Cripto", emoji: "🪙" },
  { id: "impostos", label: "Impostos", emoji: "🧾" },
];

export const TERMS: Term[] = [
  {
    id: "cdi",
    abbr: "CDI",
    name: "Certificado de Depósito Interbancário",
    category: "renda-fixa",
    short: "Taxa de referência da renda fixa no Brasil.",
    full: "O CDI é a taxa média dos empréstimos que os bancos fazem entre si, de um dia para o outro. Ele anda muito próximo da Selic e serve como principal referência (benchmark) para investimentos de renda fixa privados.",
    example: "Um CDB que rende '110% do CDI' paga 10% a mais que essa taxa de referência.",
  },
  {
    id: "cdb",
    abbr: "CDB",
    name: "Certificado de Depósito Bancário",
    category: "renda-fixa",
    short: "Você empresta dinheiro ao banco e recebe juros.",
    full: "No CDB você 'empresta' dinheiro ao banco e recebe juros em troca. Pode ser prefixado, pós-fixado (atrelado ao CDI) ou híbrido (CDI + inflação). É protegido pelo FGC até R$ 250 mil por CPF e instituição.",
    example: "Um CDB de 100% do CDI com liquidez diária é ótimo para a reserva de emergência.",
  },
  {
    id: "selic",
    abbr: "SELIC",
    name: "Sistema Especial de Liquidação e Custódia",
    category: "renda-fixa",
    short: "A taxa básica de juros da economia brasileira.",
    full: "A Selic é a taxa básica de juros do país, definida pelo Copom (Banco Central) a cada 45 dias. Ela influencia todos os outros juros: empréstimos, financiamentos, poupança e investimentos. Quando sobe, a renda fixa fica mais atraente.",
    example: "Com a Selic a 10,5% ao ano, o Tesouro Selic rende aproximadamente esse valor.",
  },
  {
    id: "ipca",
    abbr: "IPCA",
    name: "Índice de Preços ao Consumidor Amplo",
    category: "renda-fixa",
    short: "O índice oficial de inflação do Brasil.",
    full: "O IPCA mede a inflação oficial do Brasil, calculado pelo IBGE. Mostra a variação dos preços de produtos e serviços para as famílias. Investimentos 'IPCA+' garantem ganho real, acima da inflação.",
    example: "Tesouro IPCA+ 6% paga a inflação do período mais 6% ao ano de juros reais.",
  },
  {
    id: "etf",
    abbr: "ETF",
    name: "Exchange Traded Fund",
    category: "investimentos",
    short: "Fundo de índice negociado na bolsa.",
    full: "Um ETF é um fundo que replica um índice (como o Ibovespa ou o S&P 500) e é negociado na bolsa como se fosse uma ação. Permite investir em dezenas de empresas de uma vez, com baixo custo e diversificação automática.",
    example: "Comprando o ETF BOVA11, você investe nas principais ações do Ibovespa de uma só vez.",
  },
  {
    id: "fii",
    abbr: "FII",
    name: "Fundo de Investimento Imobiliário",
    category: "investimentos",
    short: "Invista em imóveis e receba aluguéis mensais.",
    full: "Os FIIs reúnem dinheiro de vários investidores para aplicar em imóveis (shoppings, galpões, lajes) ou em papéis do setor. As cotas são negociadas na bolsa e costumam distribuir rendimentos mensais isentos de IR para pessoa física.",
    example: "Com poucas centenas de reais já é possível 'virar dono' de parte de um shopping via FII.",
  },
  {
    id: "btc",
    abbr: "BTC",
    name: "Bitcoin",
    category: "cripto",
    short: "A primeira e maior criptomoeda do mundo.",
    full: "O Bitcoin é uma moeda digital descentralizada, sem banco central, registrada em uma rede pública chamada blockchain. Tem oferta limitada a 21 milhões de unidades, o que o leva a ser chamado de 'ouro digital'. É um ativo de alta volatilidade.",
    example: "Muitos investidores destinam uma pequena parte da carteira ao BTC como reserva de valor.",
  },
  {
    id: "eth",
    abbr: "ETH",
    name: "Ethereum",
    category: "cripto",
    short: "Blockchain de contratos inteligentes.",
    full: "O Ethereum é uma plataforma blockchain que vai além de pagamentos: permite criar aplicativos descentralizados (DeFi, NFTs) por meio de contratos inteligentes. Sua moeda nativa é o Ether (ETH), usada para pagar as transações da rede.",
    example: "NFTs e finanças descentralizadas (DeFi) costumam rodar sobre a rede Ethereum.",
  },
  {
    id: "fgc",
    abbr: "FGC",
    name: "Fundo Garantidor de Créditos",
    category: "renda-fixa",
    short: "Proteção de até R$ 250 mil para seus investimentos.",
    full: "O FGC é uma entidade privada que protege o investidor caso um banco quebre. Garante até R$ 250 mil por CPF e por instituição, com teto total de R$ 1 milhão a cada 4 anos. Cobre poupança, CDB, LCI e LCA, entre outros.",
    example: "Aplicar até R$ 250 mil em CDB de um banco pequeno é seguro graças ao FGC.",
  },
  {
    id: "ir",
    abbr: "IR",
    name: "Imposto de Renda",
    category: "impostos",
    short: "Tributo sobre os ganhos dos investimentos.",
    full: "O IR incide sobre o lucro de boa parte dos investimentos. Na renda fixa, segue a tabela regressiva: quanto mais tempo aplicado, menor a alíquota (de 22,5% até 15%). Alguns ativos são isentos, como LCI, LCA, poupança e rendimentos de FIIs.",
    example: "Resgatar um CDB após 2 anos paga só 15% de IR sobre o lucro, a menor alíquota.",
  },
];
