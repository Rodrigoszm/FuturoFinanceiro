export type Theme = "economia" | "cartao" | "juros" | "investimentos";

export interface Question {
  theme: Theme;
  q: string;
  options: string[];
  answer: number;
  explain: string;
}

export const THEMES: {
  id: Theme;
  label: string;
  emoji: string;
  gradient: string;
}[] = [
  { id: "economia", label: "Economia", emoji: "🐖", gradient: "from-amber-500 to-orange-600" },
  { id: "cartao", label: "Cartão", emoji: "💳", gradient: "from-rose-500 to-pink-600" },
  { id: "juros", label: "Juros", emoji: "📈", gradient: "from-blue-500 to-indigo-600" },
  { id: "investimentos", label: "Investimentos", emoji: "🏦", gradient: "from-violet-500 to-purple-600" },
];

export const QUESTIONS: Question[] = [
  // ---- Economia ----
  {
    theme: "economia",
    q: "O que é uma reserva de emergência?",
    options: [
      "Dinheiro para viajar nas férias",
      "Valor guardado para imprevistos",
      "Um investimento de alto risco",
      "Uma conta no exterior",
    ],
    answer: 1,
    explain: "A reserva cobre imprevistos como desemprego ou despesas urgentes.",
  },
  {
    theme: "economia",
    q: "A regra 50/30/20 serve para...",
    options: [
      "Dividir o orçamento mensal",
      "Calcular impostos",
      "Escolher ações",
      "Definir o câmbio",
    ],
    answer: 0,
    explain: "50% necessidades, 30% desejos e 20% para poupar e investir.",
  },
  {
    theme: "economia",
    q: "Qual hábito ajuda a economizar no dia a dia?",
    options: [
      "Comprar por impulso",
      "Pagar só o mínimo da fatura",
      "Fazer lista antes de ir ao mercado",
      "Ignorar os preços",
    ],
    answer: 2,
    explain: "Planejar as compras evita gastos desnecessários por impulso.",
  },
  // ---- Cartão ----
  {
    theme: "cartao",
    q: "O que acontece se você paga só o mínimo da fatura?",
    options: [
      "Ganha desconto",
      "O restante entra no rotativo com juros altos",
      "A dívida desaparece",
      "Não muda nada",
    ],
    answer: 1,
    explain: "O rotativo do cartão é um dos juros mais altos do Brasil.",
  },
  {
    theme: "cartao",
    q: "Qual é a melhor prática com o cartão de crédito?",
    options: [
      "Pagar a fatura integral em dia",
      "Usar todo o limite sempre",
      "Atrasar para acumular pontos",
      "Fazer só o pagamento mínimo",
    ],
    answer: 0,
    explain: "Pagando tudo em dia você usa o crédito sem pagar juros.",
  },
  {
    theme: "cartao",
    q: "O prazo sem juros do cartão pode chegar a quantos dias?",
    options: ["Até 7 dias", "Até 15 dias", "Até cerca de 40 dias", "Nunca há prazo"],
    answer: 2,
    explain: "Comprando no início do ciclo, dá para ter até ~40 dias sem juros.",
  },
  // ---- Juros ----
  {
    theme: "juros",
    q: "Juros compostos são...",
    options: [
      "Juros só sobre o valor inicial",
      "Juros que diminuem com o tempo",
      "Juros sobre juros acumulados",
      "Uma taxa fixa do governo",
    ],
    answer: 2,
    explain: "Os juros rendem sobre o total acumulado: o efeito bola de neve.",
  },
  {
    theme: "juros",
    q: "Nos juros simples, a taxa incide sobre...",
    options: [
      "O valor inicial sempre",
      "O total acumulado",
      "Apenas os juros",
      "A inflação",
    ],
    answer: 0,
    explain: "Juros simples sempre usam o capital original como base.",
  },
  {
    theme: "juros",
    q: "Qual fator mais potencializa os juros compostos?",
    options: ["O tempo", "A sorte", "O banco", "O feriado"],
    answer: 0,
    explain: "Quanto mais tempo, maior o crescimento exponencial.",
  },
  // ---- Investimentos ----
  {
    theme: "investimentos",
    q: "Qual investimento é mais conservador?",
    options: ["Ações", "Criptomoedas", "Tesouro Selic", "Day trade"],
    answer: 2,
    explain: "O Tesouro Selic é seguro e tem liquidez diária.",
  },
  {
    theme: "investimentos",
    q: "Até quanto o FGC protege por CPF e instituição?",
    options: ["R$ 50 mil", "R$ 100 mil", "R$ 250 mil", "Sem limite"],
    answer: 2,
    explain: "O FGC garante até R$ 250 mil por CPF em cada instituição.",
  },
  {
    theme: "investimentos",
    q: "Um CDB que paga '100% do CDI' rende perto de qual taxa?",
    options: ["Da poupança", "Da Selic", "Do dólar", "Da inflação americana"],
    answer: 1,
    explain: "O CDI acompanha de perto a taxa Selic.",
  },
];

export interface Medal {
  min: number; // pontos percentuais mínimos
  emoji: string;
  title: string;
  desc: string;
}

export const MEDALS: Medal[] = [
  { min: 90, emoji: "🏆", title: "Mestre das Finanças", desc: "Conhecimento de outro nível!" },
  { min: 70, emoji: "🥇", title: "Investidor Ouro", desc: "Você manda muito bem!" },
  { min: 50, emoji: "🥈", title: "Poupador Prata", desc: "Bom caminho, continue!" },
  { min: 0, emoji: "🌱", title: "Iniciante", desc: "Todo expert já começou aqui." },
];

export function getMedal(pct: number): Medal {
  return MEDALS.find((m) => pct >= m.min) ?? MEDALS[MEDALS.length - 1];
}
