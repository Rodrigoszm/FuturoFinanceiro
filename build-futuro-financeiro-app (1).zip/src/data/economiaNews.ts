import type { AssetQuote } from "./economiaApi";

export interface NewsItem {
  emoji: string;
  text: string;
  tone: "up" | "down" | "neutral";
}

function brl(n: number) {
  return n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

/** Gera mini notícias automáticas a partir das cotações ao vivo. */
export function buildNews(quotes: AssetQuote[]): NewsItem[] {
  const news: NewsItem[] = [];

  for (const q of quotes) {
    const up = q.pctChange >= 0;
    const strong = Math.abs(q.pctChange) >= 1.5;

    let text: string;
    if (up && strong) {
      text = `${q.code} dispara ${q.pctChange.toFixed(2)}% e é cotado a ${brl(q.value)}.`;
    } else if (up) {
      text = `${q.code} sobe ${q.pctChange.toFixed(2)}%, negociado a ${brl(q.value)}.`;
    } else if (strong) {
      text = `${q.code} recua ${Math.abs(q.pctChange).toFixed(2)}% e vai a ${brl(q.value)}.`;
    } else {
      text = `${q.code} cai ${Math.abs(q.pctChange).toFixed(2)}%, cotado a ${brl(q.value)}.`;
    }

    news.push({
      emoji: q.emoji,
      text,
      tone: q.pctChange === 0 ? "neutral" : up ? "up" : "down",
    });
  }

  // ordena: maiores variações (em módulo) primeiro
  return news;
}
