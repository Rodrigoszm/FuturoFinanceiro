export type TxType = "in" | "out";

export interface Transaction {
  id: string;
  type: TxType;
  description: string;
  value: number;
  category: string;
  date: string; // ISO string
}

export interface Category {
  id: string;
  label: string;
  emoji: string;
  autoDescription: string; // preenchido automaticamente ao clicar
  color: string;           // nome da cor para o gráfico / destaque
  hex: string;             // cor hex para DonutChart
  type: TxType;
}

export const CATEGORIES: Category[] = [
  /* ─────────── RECEITAS ─────────── */
  { id: "salario",      label: "Salário",       emoji: "💼", autoDescription: "Salário",              color: "emerald", hex: "#10b981", type: "in" },
  { id: "pix-in",       label: "PIX Recebido",  emoji: "⚡", autoDescription: "PIX Recebido",         color: "teal",    hex: "#14b8a6", type: "in" },
  { id: "freelance",    label: "Freelance",     emoji: "💻", autoDescription: "Freelance",             color: "cyan",    hex: "#06b6d4", type: "in" },
  { id: "comissao",     label: "Comissão",      emoji: "🤝", autoDescription: "Comissão",              color: "green",   hex: "#22c55e", type: "in" },
  { id: "vendas",       label: "Vendas",        emoji: "🛒", autoDescription: "Vendas",                color: "lime",    hex: "#84cc16", type: "in" },
  { id: "investimento", label: "Investimentos", emoji: "📈", autoDescription: "Rendimento investimento", color: "indigo", hex: "#6366f1", type: "in" },

  /* ─────────── DESPESAS ─────────── */
  { id: "agua",         label: "Água",          emoji: "💧", autoDescription: "Conta de Água",         color: "sky",    hex: "#0ea5e9", type: "out" },
  { id: "luz",          label: "Luz",           emoji: "⚡", autoDescription: "Conta de Luz",          color: "amber",  hex: "#f59e0b", type: "out" },
  { id: "internet",     label: "Internet",      emoji: "📶", autoDescription: "Internet",               color: "violet", hex: "#8b5cf6", type: "out" },
  { id: "aluguel",      label: "Aluguel",       emoji: "🏠", autoDescription: "Aluguel",                color: "blue",   hex: "#3b82f6", type: "out" },
  { id: "ipva",         label: "IPVA",          emoji: "📋", autoDescription: "IPVA",                   color: "slate",  hex: "#64748b", type: "out" },
  { id: "cartao",       label: "Cartão",        emoji: "💳", autoDescription: "Cartão de Crédito",      color: "rose",   hex: "#f43f5e", type: "out" },
  { id: "supermercado", label: "Supermercado",  emoji: "🛒", autoDescription: "Compras Supermercado",   color: "orange", hex: "#f97316", type: "out" },
  { id: "farmacia",     label: "Farmácia",      emoji: "💊", autoDescription: "Farmácia",               color: "red",    hex: "#ef4444", type: "out" },
  { id: "parc-carro",   label: "Parcela Carro", emoji: "🚗", autoDescription: "Parcela do Carro",       color: "zinc",   hex: "#71717a", type: "out" },
  { id: "parc-moto",    label: "Parcela Moto",  emoji: "🏍️", autoDescription: "Parcela da Moto",        color: "stone",  hex: "#78716c", type: "out" },
  { id: "gasolina",     label: "Gasolina",      emoji: "⛽", autoDescription: "Gasolina",               color: "yellow", hex: "#eab308", type: "out" },
  { id: "uber",         label: "Uber",          emoji: "🚕", autoDescription: "Uber / Transporte",      color: "neutral",hex: "#737373", type: "out" },
  { id: "streaming",    label: "Streaming",     emoji: "🎬", autoDescription: "Streaming",              color: "purple", hex: "#a855f7", type: "out" },
  { id: "escola",       label: "Escola",        emoji: "🏫", autoDescription: "Escola",                 color: "teal",   hex: "#14b8a6", type: "out" },
  { id: "faculdade",    label: "Faculdade",     emoji: "🎓", autoDescription: "Faculdade",              color: "indigo", hex: "#6366f1", type: "out" },
  { id: "lazer",        label: "Lazer",         emoji: "🎮", autoDescription: "Lazer",                  color: "violet", hex: "#8b5cf6", type: "out" },
  { id: "academia",     label: "Academia",      emoji: "🏋️", autoDescription: "Academia",               color: "lime",   hex: "#84cc16", type: "out" },
  { id: "restaurante",  label: "Restaurante",   emoji: "🍽️", autoDescription: "Restaurante",            color: "orange", hex: "#f97316", type: "out" },
  { id: "outros-out",   label: "Outros",        emoji: "📦", autoDescription: "Outros",                 color: "slate",  hex: "#94a3b8", type: "out" },
];

export function getCategory(id: string): Category | undefined {
  return CATEGORIES.find((c) => c.id === id);
}

/** Cores hex para o DonutChart, gerado dinamicamente das categorias. */
export const CHART_COLORS: Record<string, string> = Object.fromEntries(
  CATEGORIES.filter((c) => c.type === "out").map((c) => [c.id, c.hex]),
);

export function brl(n: number) {
  return n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

export function formatDate(iso: string) {
  const d = new Date(iso);
  return d.toLocaleDateString("pt-BR", { day: "2-digit", month: "short" });
}
