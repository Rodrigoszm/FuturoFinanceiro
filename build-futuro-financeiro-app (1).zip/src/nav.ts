import type { NavItem } from "./types";

export const NAV_ITEMS: NavItem[] = [
  { id: "home", label: "Início", icon: "🏠" },
  { id: "aprender", label: "Aprender", icon: "📚" },
  { id: "calculadoras", label: "Calcular", icon: "🧮" },
  { id: "moedas", label: "Moedas", icon: "💱" },
  { id: "quiz", label: "Quiz", icon: "🎯" },
  { id: "dinheiro", label: "Carteira", icon: "💰" },
];
