import { useState } from "react";
import { SectionTitle } from "../components/ui/SectionTitle";
import {
  PercentCalc,
  DiscountCalc,
  SimpleInterestCalc,
  CompoundInterestCalc,
  InstallmentCalc,
} from "../components/calc/Calculators";

type CalcId =
  | "porcentagem"
  | "desconto"
  | "simples"
  | "compostos"
  | "parcelas";

const TABS: { id: CalcId; emoji: string; label: string }[] = [
  { id: "porcentagem", emoji: "％", label: "Porcentagem" },
  { id: "desconto", emoji: "🏷️", label: "Desconto" },
  { id: "simples", emoji: "➕", label: "J. Simples" },
  { id: "compostos", emoji: "📈", label: "J. Compostos" },
  { id: "parcelas", emoji: "🧾", label: "Parcelas" },
];

export function Calculadoras() {
  const [active, setActive] = useState<CalcId>("porcentagem");

  return (
    <div className="space-y-5">
      <SectionTitle
        emoji="🧮"
        title="Calculadoras"
        subtitle="Ferramentas práticas para o seu dia a dia financeiro."
      />

      {/* Tab selector — horizontal scroll on mobile */}
      <div className="-mx-4 overflow-x-auto px-4 pb-1">
        <div className="flex gap-2">
          {TABS.map((t) => {
            const on = active === t.id;
            return (
              <button
                key={t.id}
                onClick={() => setActive(t.id)}
                className={`flex shrink-0 items-center gap-1.5 rounded-full px-4 py-2 text-sm font-semibold transition ${
                  on
                    ? "bg-gradient-to-r from-emerald-500 to-blue-600 text-white shadow-md shadow-emerald-200"
                    : "border border-slate-200 bg-white text-slate-600 hover:bg-slate-50"
                }`}
              >
                <span>{t.emoji}</span>
                {t.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Each calculator works independently */}
      {active === "porcentagem" && <PercentCalc />}
      {active === "desconto" && <DiscountCalc />}
      {active === "simples" && <SimpleInterestCalc />}
      {active === "compostos" && <CompoundInterestCalc />}
      {active === "parcelas" && <InstallmentCalc />}

      <p className="px-1 text-center text-xs text-slate-400">
        Os cálculos são estimativas para fins educativos.
      </p>
    </div>
  );
}
