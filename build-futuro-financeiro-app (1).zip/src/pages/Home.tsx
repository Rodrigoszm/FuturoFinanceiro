import { useMemo, useState } from "react";
import type { ReactElement } from "react";
import { Card } from "../components/ui/Card";
import { Modal } from "../components/ui/Modal";
import type { PageId } from "../types";
import {
  LearnIcon,
  CalcIcon,
  CoinsIcon,
  QuizIcon,
  WalletIcon,
} from "../components/icons/NavIcons";

interface PageProps {
  onNavigate: (page: PageId) => void;
}

/* ----------------------------- helpers ----------------------------- */

function getGreeting() {
  const h = new Date().getHours();
  if (h < 12) return { text: "Bom dia", emoji: "☀️" };
  if (h < 18) return { text: "Boa tarde", emoji: "🌤️" };
  return { text: "Boa noite", emoji: "🌙" };
}

const QUOTES = [
  "Pequenos hábitos hoje constroem grandes patrimônios amanhã.",
  "O melhor momento para investir foi ontem. O segundo melhor é agora.",
  "Cuide do seu dinheiro e ele cuidará do seu futuro.",
  "Liberdade financeira começa com uma decisão por dia.",
  "Gaste menos do que ganha e invista a diferença.",
];

interface Tip {
  emoji: string;
  title: string;
  text: string;
  content: string[];
}

const TIPS: Tip[] = [
  {
    emoji: "⚖️",
    title: "Regra 50/30/20",
    text: "Use 50% da renda para necessidades, 30% para desejos e 20% para poupar e investir.",
    content: [
      "A regra 50/30/20 é um método simples para organizar o orçamento mensal sem planilhas complicadas.",
      "💡 50% — Necessidades: aluguel, contas, alimentação, transporte e tudo que é essencial para viver.",
      "🎉 30% — Desejos: lazer, restaurantes, streaming, viagens e gastos que melhoram sua qualidade de vida.",
      "📈 20% — Futuro: reserva de emergência, investimentos e quitação de dívidas.",
      "Comece adaptando os percentuais à sua realidade. O importante é sempre reservar uma parte para o seu futuro.",
    ],
  },
  {
    emoji: "🛟",
    title: "Reserva de emergência",
    text: "Tenha de 3 a 6 meses de despesas guardados em um investimento de fácil acesso.",
    content: [
      "A reserva de emergência é o seu colchão de segurança para imprevistos como desemprego, problemas de saúde ou reparos urgentes.",
      "🎯 Quanto guardar: de 3 a 6 meses do seu custo de vida mensal. Se você tem renda instável, mire em 12 meses.",
      "🏦 Onde guardar: em aplicações seguras e com liquidez diária, como Tesouro Selic ou CDBs que rendem 100%+ do CDI com resgate imediato.",
      "⚠️ Evite: deixar a reserva na poupança (rende pouco) ou em investimentos de risco que podem cair quando você mais precisar.",
      "Só comece a investir em ativos de maior risco depois que sua reserva estiver completa.",
    ],
  },
  {
    emoji: "📈",
    title: "Juros compostos",
    text: "Comece cedo. O tempo é o ingrediente mais poderoso dos seus rendimentos.",
    content: [
      "Juros compostos são os 'juros sobre juros': seus rendimentos passam a gerar novos rendimentos ao longo do tempo.",
      "❄️ É o efeito bola de neve. No começo o crescimento parece lento, mas depois acelera de forma impressionante.",
      "⏰ O tempo importa mais que o valor. Quem começa cedo, mesmo investindo pouco, costuma terminar com mais dinheiro do que quem começa tarde investindo muito.",
      "💰 Exemplo: R$ 200/mês a 0,8% ao mês por 30 anos pode superar R$ 500 mil — sendo a maior parte fruto dos juros, não dos aportes.",
      "A lição: comece hoje, seja constante e deixe o tempo trabalhar a seu favor.",
    ],
  },
  {
    emoji: "💳",
    title: "Evite o crédito caro",
    text: "Cartão e cheque especial têm os juros mais altos. Quite essas dívidas primeiro.",
    content: [
      "Nem toda dívida é igual. As mais perigosas são as de juros altíssimos, que crescem rápido e corroem seu orçamento.",
      "🚨 Os vilões: rotativo do cartão de crédito e cheque especial podem passar de 300% ao ano.",
      "✅ Estratégia: liste suas dívidas e quite primeiro as de maior taxa de juros (método avalanche). Isso economiza mais dinheiro.",
      "🔄 Considere portabilidade ou empréstimos mais baratos para trocar uma dívida cara por uma barata.",
      "Regra de ouro: não faz sentido investir buscando 1% ao mês enquanto paga 15% ao mês em dívidas.",
    ],
  },
];

/* daily index so quote & tip change once per day but stay stable */
function dailyIndex(len: number) {
  const day = Math.floor(Date.now() / 86_400_000);
  return day % len;
}

/* ------------------------------ cards ------------------------------ */

interface FeatureCard {
  id: PageId;
  title: string;
  desc: string;
  Icon: (p: { className?: string }) => ReactElement;
  gradient: string;
}

const FEATURES: FeatureCard[] = [
  {
    id: "aprender",
    title: "Aprender",
    desc: "Trilhas e artigos",
    Icon: LearnIcon,
    gradient: "from-emerald-500 to-teal-600",
  },
  {
    id: "calculadoras",
    title: "Calculadoras",
    desc: "Juros e metas",
    Icon: CalcIcon,
    gradient: "from-blue-500 to-indigo-600",
  },
  {
    id: "moedas",
    title: "Conversor",
    desc: "Cotações em tempo real",
    Icon: CoinsIcon,
    gradient: "from-amber-500 to-orange-600",
  },
  {
    id: "quiz",
    title: "Quiz",
    desc: "Teste seu saber",
    Icon: QuizIcon,
    gradient: "from-violet-500 to-purple-600",
  },
  {
    id: "dinheiro",
    title: "Meu Dinheiro",
    desc: "Controle de gastos",
    Icon: WalletIcon,
    gradient: "from-rose-500 to-pink-600",
  },
  {
    id: "dicionario",
    title: "Dicionário",
    desc: "Termos financeiros de A a Z",
    Icon: LearnIcon,
    gradient: "from-slate-600 to-slate-800",
  },
];

/* ------------------------------ page ------------------------------- */

export function Home({ onNavigate }: PageProps) {
  const greeting = useMemo(getGreeting, []);
  const quote = QUOTES[dailyIndex(QUOTES.length)];
  const tip = TIPS[dailyIndex(TIPS.length)];
  const [activeTip, setActiveTip] = useState<Tip | null>(null);

  return (
    <div className="space-y-7">
      {/* Greeting + motivational hero */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-900 via-emerald-800 to-emerald-950 p-6 text-white shadow-xl shadow-emerald-900/30 ring-1 ring-amber-400/20">
        {/* decorative blobs */}
        <div className="pointer-events-none absolute -right-10 -top-10 h-40 w-40 rounded-full bg-white/10 blur-2xl" />
        <div className="pointer-events-none absolute -bottom-12 -left-6 h-36 w-36 rounded-full bg-amber-300/15 blur-2xl" />
        <div className="pointer-events-none absolute inset-x-6 bottom-0 h-px bg-gradient-to-r from-transparent via-amber-400/40 to-transparent" />

        <div className="relative">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-white/80">
                {greeting.text} {greeting.emoji}
              </p>
              <h1 className="mt-0.5 text-2xl font-extrabold tracking-tight">
                Investidor(a)
              </h1>
            </div>
            <button
              onClick={() => onNavigate("dinheiro")}
              className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white/15 text-lg backdrop-blur transition hover:bg-white/25"
              aria-label="Minha carteira"
            >
              💼
            </button>
          </div>

          <div className="mt-5 rounded-2xl bg-white/10 p-4 backdrop-blur-sm">
            <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-amber-300/90">
              Frase do dia
            </p>
            <p className="mt-1 text-sm font-medium leading-relaxed text-white">
              “{quote}”
            </p>
          </div>
        </div>
      </section>

      {/* Quick stats */}
      <section className="grid grid-cols-3 gap-3">
        {[
          { v: "+120", l: "Artigos", c: "text-emerald-600" },
          { v: "8", l: "Calculadoras", c: "text-blue-600" },
          { v: "50+", l: "Perguntas", c: "text-violet-600" },
        ].map((s) => (
          <Card key={s.l} className="!p-3 text-center">
            <p className={`text-xl font-extrabold ${s.c}`}>{s.v}</p>
            <p className="text-[11px] text-slate-500">{s.l}</p>
          </Card>
        ))}
      </section>

      {/* Main feature cards */}
      <section>
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-lg font-bold text-slate-900">O que vamos fazer hoje?</h2>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {FEATURES.map((f, idx) => {
            const Icon = f.Icon;
            const wide = idx === FEATURES.length - 1; // last card full width
            return (
              <button
                key={f.id}
                onClick={() => onNavigate(f.id)}
                className={`group relative flex items-center gap-3 overflow-hidden rounded-2xl border border-slate-100 bg-white p-4 text-left shadow-sm shadow-slate-200/50 transition hover:-translate-y-0.5 hover:shadow-md active:scale-[0.99] ${
                  wide ? "col-span-2" : ""
                }`}
              >
                <span
                  className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br ${f.gradient} text-white shadow-md`}
                >
                  <Icon className="h-6 w-6" />
                </span>
                <span className="min-w-0">
                  <span className="block font-semibold text-slate-900">
                    {f.title}
                  </span>
                  <span className="block truncate text-xs text-slate-500">
                    {f.desc}
                  </span>
                </span>
                <span className="ml-auto text-slate-300 transition group-hover:translate-x-0.5 group-hover:text-slate-400">
                  ›
                </span>
              </button>
            );
          })}
        </div>
      </section>

      {/* Tip of the day */}
      <section>
        <h2 className="mb-3 text-lg font-bold text-slate-900">Dica do dia 💡</h2>
        <Card
          onClick={() => setActiveTip(tip)}
          className="relative overflow-hidden border-emerald-100 bg-gradient-to-br from-emerald-50 to-blue-50"
        >
          <div className="pointer-events-none absolute -right-6 -top-6 h-24 w-24 rounded-full bg-emerald-200/30 blur-xl" />
          <div className="relative flex gap-4">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-white text-2xl shadow-sm">
              {tip.emoji}
            </div>
            <div>
              <h3 className="font-bold text-slate-900">{tip.title}</h3>
              <p className="mt-1 text-sm leading-relaxed text-slate-600">
                {tip.text}
              </p>
              <span className="mt-3 inline-block text-sm font-semibold text-emerald-700">
                Ler dica completa →
              </span>
            </div>
          </div>
        </Card>
      </section>

      {/* All tips */}
      <section>
        <h2 className="mb-3 text-lg font-bold text-slate-900">Mais dicas 📚</h2>
        <div className="grid grid-cols-2 gap-3">
          {TIPS.map((t) => (
            <button
              key={t.title}
              onClick={() => setActiveTip(t)}
              className="group flex flex-col items-start rounded-2xl border border-slate-100 bg-white p-4 text-left shadow-sm shadow-slate-200/50 transition hover:-translate-y-0.5 hover:shadow-md active:scale-[0.99]"
            >
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-50 to-blue-50 text-2xl">
                {t.emoji}
              </span>
              <span className="mt-3 font-semibold text-slate-900">
                {t.title}
              </span>
              <span className="mt-1 line-clamp-2 text-xs text-slate-500">
                {t.text}
              </span>
              <span className="mt-2 text-xs font-semibold text-emerald-600 transition group-hover:translate-x-0.5">
                Ver mais →
              </span>
            </button>
          ))}
        </div>
      </section>

      {/* Bottom CTA */}
      <section>
        <Card
          onClick={() => onNavigate("quiz")}
          className="flex items-center gap-4 bg-gradient-to-r from-slate-900 to-slate-800 text-white"
        >
          <div className="text-3xl">🎯</div>
          <div className="flex-1">
            <h3 className="font-bold">Desafio relâmpago</h3>
            <p className="text-sm text-white/70">
              Responda 4 perguntas e teste seu nível.
            </p>
          </div>
          <span className="rounded-xl bg-white/15 px-3 py-2 text-sm font-semibold backdrop-blur">
            Jogar
          </span>
        </Card>
      </section>

      {/* Tip detail modal */}
      <Modal
        open={activeTip !== null}
        onClose={() => setActiveTip(null)}
        title={activeTip ? `${activeTip.emoji} ${activeTip.title}` : ""}
      >
        {activeTip && (
          <div className="space-y-3 pb-2">
            <div className="rounded-2xl bg-gradient-to-br from-emerald-50 to-blue-50 p-4 text-sm font-medium text-slate-700">
              {activeTip.text}
            </div>
            {activeTip.content.map((p, i) => (
              <p key={i} className="text-sm leading-relaxed text-slate-600">
                {p}
              </p>
            ))}
          </div>
        )}
      </Modal>
    </div>
  );
}
