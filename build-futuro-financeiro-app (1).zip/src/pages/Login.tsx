import { useState } from "react";
import { Card } from "../components/ui/Card";
import { Button } from "../components/ui/Button";
import { useAuth } from "../auth/AuthContext";
import { Logo } from "../components/brand/Logo";
import type { PageId } from "../types";

interface PageProps {
  onNavigate: (page: PageId) => void;
}

export function Login({ onNavigate }: PageProps) {
  const {
    user,
    isAuthenticated,
    login,
    signup,
    logout,
    mode: authMode,
    loading: authLoading,
  } = useAuth();

  const [mode, setMode] = useState<"login" | "signup">("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);

  const inputCls =
    "w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none transition focus:border-emerald-400 focus:bg-white focus:ring-2 focus:ring-emerald-100";

  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const res =
        mode === "login"
          ? await login(email, password)
          : await signup(name, email, password);
      if (!res.ok) {
        setError(res.error ?? "Algo deu errado.");
        return;
      }
      setName("");
      setEmail("");
      setPassword("");
      onNavigate("home");
    } finally {
      setSubmitting(false);
    }
  }

  /* ----------------------------- LOADING ---------------------------- */
  if (authLoading) {
    return (
      <div className="mx-auto flex max-w-md flex-col items-center gap-3 pt-16 text-slate-500">
        <span className="h-8 w-8 animate-spin rounded-full border-2 border-emerald-600 border-t-transparent" />
        <p className="text-sm">Verificando sua sessão...</p>
      </div>
    );
  }

  /* --------------------------- LOGGED IN --------------------------- */
  if (isAuthenticated && user) {
    return (
      <div className="mx-auto max-w-md space-y-6 pt-4">
        <div className="text-center">
          <img
            src={user.avatar}
            alt={user.name}
            className="mx-auto h-24 w-24 rounded-3xl border-4 border-white shadow-lg shadow-emerald-200"
          />
          <h1 className="mt-4 text-2xl font-extrabold text-slate-900">
            Olá, {user.name.split(" ")[0]}! 👋
          </h1>
          <p className="text-sm text-slate-500">{user.email}</p>
        </div>

        <Card>
          <h3 className="mb-3 text-sm font-bold uppercase tracking-wide text-slate-400">
            Sua conta
          </h3>
          <dl className="space-y-3 text-sm">
            <div className="flex items-center justify-between">
              <dt className="text-slate-500">Nome</dt>
              <dd className="font-semibold text-slate-800">{user.name}</dd>
            </div>
            <div className="flex items-center justify-between">
              <dt className="text-slate-500">E-mail</dt>
              <dd className="font-semibold text-slate-800">{user.email}</dd>
            </div>
            <div className="flex items-center justify-between">
              <dt className="text-slate-500">Token local</dt>
              <dd className="max-w-[55%] truncate font-mono text-xs text-slate-400">
                {user.token}
              </dd>
            </div>
            <div className="flex items-center justify-between">
              <dt className="text-slate-500">Backend</dt>
              <dd>
                <span
                  className={`rounded-full px-2 py-0.5 text-xs font-bold ${
                    authMode === "firebase"
                      ? "bg-amber-100 text-amber-700"
                      : "bg-emerald-100 text-emerald-700"
                  }`}
                >
                  {authMode === "firebase" ? "🔥 Firebase" : "💾 Local"}
                </span>
              </dd>
            </div>
            <div className="flex items-center justify-between">
              <dt className="text-slate-500">Membro desde</dt>
              <dd className="font-semibold text-slate-800">
                {new Date(user.createdAt).toLocaleDateString("pt-BR")}
              </dd>
            </div>
          </dl>
        </Card>

        <div className="grid grid-cols-2 gap-3">
          <Button variant="secondary" onClick={() => onNavigate("dinheiro")}>
            💰 Meu Dinheiro
          </Button>
          <Button
            variant="secondary"
            onClick={logout}
            className="!border-rose-200 !text-rose-600"
          >
            Sair
          </Button>
        </div>

        <p className="text-center text-xs text-slate-400">
          Sessão salva localmente neste dispositivo.
        </p>
      </div>
    );
  }

  /* ---------------------------- AUTH FORM --------------------------- */
  return (
    <div className="mx-auto max-w-md space-y-6 pt-4">
      <div className="text-center">
        <div className="mx-auto inline-flex">
          <Logo size="lg" />
        </div>
        <h1
          className="mt-4 text-2xl font-extrabold text-emerald-950"
          style={{ fontFamily: "Georgia, 'Times New Roman', serif" }}
        >
          {mode === "login" ? "Bem-vindo de volta" : "Crie sua conta"}
        </h1>
        <p className="text-sm text-slate-500">
          {mode === "login"
            ? "Entre para continuar aprendendo."
            : "Comece sua jornada financeira."}
        </p>
      </div>

      <Card>
        <form className="space-y-3" onSubmit={handleSubmit}>
          {mode === "signup" && (
            <input
              className={inputCls}
              placeholder="Nome completo"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          )}
          <input
            className={inputCls}
            type="email"
            placeholder="E-mail"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <input
            className={inputCls}
            type="password"
            placeholder="Senha (mín. 4 caracteres)"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />

          {error && (
            <p className="rounded-xl bg-rose-50 px-3 py-2 text-xs font-medium text-rose-600">
              ⚠️ {error}
            </p>
          )}

          <Button type="submit" className="w-full" disabled={submitting}>
            {submitting
              ? "Aguarde..."
              : mode === "login"
                ? "Entrar"
                : "Cadastrar"}
          </Button>
        </form>

        <div className="my-4 flex items-center gap-3 text-xs text-slate-300">
          <div className="h-px flex-1 bg-slate-100" />
          ou
          <div className="h-px flex-1 bg-slate-100" />
        </div>

        <Button
          variant="secondary"
          className="w-full"
          onClick={async () => {
            setError(null);
            setSubmitting(true);
            try {
              const demoEmail = "demo@futuro.com";
              const r = await login(demoEmail, "1234");
              if (!r.ok) await signup("Visitante Demo", demoEmail, "1234");
              onNavigate("home");
            } finally {
              setSubmitting(false);
            }
          }}
          disabled={submitting}
        >
          🚀 Entrar como visitante
        </Button>
      </Card>

      <p className="text-center text-sm text-slate-500">
        {mode === "login" ? "Não tem conta?" : "Já tem conta?"}{" "}
        <button
          onClick={() => {
            setMode(mode === "login" ? "signup" : "login");
            setError(null);
          }}
          className="font-semibold text-emerald-600 hover:underline"
        >
          {mode === "login" ? "Cadastre-se" : "Entrar"}
        </button>
      </p>
    </div>
  );
}
