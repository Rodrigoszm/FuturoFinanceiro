import { useMemo, useState } from "react";
import { SectionTitle } from "../components/ui/SectionTitle";
import { Card } from "../components/ui/Card";
import { Button } from "../components/ui/Button";
import { useLocalStorage } from "../hooks/useLocalStorage";
import {
  QUESTIONS,
  THEMES,
  getMedal,
  type Question,
  type Theme,
} from "../data/quizData";

interface Stats {
  bestPct: number;
  played: number;
  totalCorrect: number;
}

const DEFAULT_STATS: Stats = { bestPct: 0, played: 0, totalCorrect: 0 };

type Screen = "start" | "playing" | "result";

export function Quiz() {
  const [stats, setStats] = useLocalStorage<Stats>("ff_quiz_stats", DEFAULT_STATS);

  const [screen, setScreen] = useState<Screen>("start");
  const [theme, setTheme] = useState<Theme | "all">("all");
  const [deck, setDeck] = useState<Question[]>([]);
  const [step, setStep] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [score, setScore] = useState(0);

  const current = deck[step];
  const progress = deck.length ? ((step + (selected !== null ? 1 : 0)) / deck.length) * 100 : 0;

  function startQuiz() {
    const pool =
      theme === "all" ? QUESTIONS : QUESTIONS.filter((q) => q.theme === theme);
    const shuffled = [...pool].sort(() => Math.random() - 0.5);
    setDeck(shuffled);
    setStep(0);
    setSelected(null);
    setScore(0);
    setScreen("playing");
  }

  function choose(i: number) {
    if (selected !== null) return;
    setSelected(i);
    if (i === current.answer) setScore((s) => s + 1);
  }

  function next() {
    if (step + 1 >= deck.length) {
      finish();
    } else {
      setStep((s) => s + 1);
      setSelected(null);
    }
  }

  function finish() {
    const pct = Math.round((score / deck.length) * 100);
    setStats((prev) => ({
      bestPct: Math.max(prev.bestPct, pct),
      played: prev.played + 1,
      totalCorrect: prev.totalCorrect + score,
    }));
    setScreen("result");
  }

  /* ----------------------------- START ----------------------------- */
  if (screen === "start") {
    return (
      <div className="space-y-6">
        <SectionTitle
          emoji="🎯"
          title="Quiz Financeiro"
          subtitle="Teste seus conhecimentos e ganhe medalhas!"
        />

        {/* Stats banner */}
        <Card className="bg-gradient-to-br from-emerald-600 to-blue-700 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-white/80">Seu recorde</p>
              <p className="text-3xl font-extrabold">{stats.bestPct}%</p>
            </div>
            <div className="text-4xl">{getMedal(stats.bestPct).emoji}</div>
          </div>
          <div className="mt-3 flex gap-3 text-xs">
            <div className="flex-1 rounded-xl bg-white/15 p-2 text-center backdrop-blur">
              <p className="font-bold">{stats.played}</p>
              <p className="text-white/70">Quizzes</p>
            </div>
            <div className="flex-1 rounded-xl bg-white/15 p-2 text-center backdrop-blur">
              <p className="font-bold">{stats.totalCorrect}</p>
              <p className="text-white/70">Acertos totais</p>
            </div>
          </div>
        </Card>

        <div>
          <h3 className="mb-3 text-sm font-bold uppercase tracking-wide text-slate-400">
            Escolha um tema
          </h3>
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => setTheme("all")}
              className={`col-span-2 rounded-2xl border p-4 text-left transition active:scale-[0.99] ${
                theme === "all"
                  ? "border-emerald-400 bg-emerald-50 ring-2 ring-emerald-100"
                  : "border-slate-100 bg-white"
              }`}
            >
              <span className="text-2xl">🎲</span>
              <p className="mt-1 font-semibold text-slate-900">Todos os temas</p>
              <p className="text-xs text-slate-500">
                {QUESTIONS.length} perguntas embaralhadas
              </p>
            </button>

            {THEMES.map((t) => {
              const on = theme === t.id;
              const count = QUESTIONS.filter((q) => q.theme === t.id).length;
              return (
                <button
                  key={t.id}
                  onClick={() => setTheme(t.id)}
                  className={`rounded-2xl border p-4 text-left transition active:scale-[0.99] ${
                    on
                      ? "border-emerald-400 bg-emerald-50 ring-2 ring-emerald-100"
                      : "border-slate-100 bg-white"
                  }`}
                >
                  <span
                    className={`inline-flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${t.gradient} text-lg text-white shadow`}
                  >
                    {t.emoji}
                  </span>
                  <p className="mt-2 font-semibold text-slate-900">{t.label}</p>
                  <p className="text-xs text-slate-500">{count} perguntas</p>
                </button>
              );
            })}
          </div>
        </div>

        <Button onClick={startQuiz} className="w-full">
          Começar quiz →
        </Button>
      </div>
    );
  }

  /* ---------------------------- PLAYING ---------------------------- */
  if (screen === "playing" && current) {
    return (
      <div className="space-y-5">
        <SectionTitle emoji="🎯" title="Quiz Financeiro" />

        <div className="flex items-center justify-between text-xs font-medium text-slate-400">
          <span>
            Pergunta {step + 1}/{deck.length}
          </span>
          <span className="font-bold text-emerald-600">⭐ {score} pts</span>
        </div>
        <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-100">
          <div
            className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-blue-600 transition-all duration-500 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>

        <Card key={step} className="animate-[fadeIn_0.3s_ease-out]">
          <h3 className="text-lg font-bold leading-snug text-slate-900">
            {current.q}
          </h3>

          <div className="mt-4 space-y-2.5">
            {current.options.map((opt, i) => {
              const isAnswer = i === current.answer;
              const isPicked = i === selected;
              let cls = "border-slate-200 bg-white text-slate-700 hover:bg-slate-50";
              if (selected !== null) {
                if (isAnswer)
                  cls = "border-emerald-400 bg-emerald-50 text-emerald-700";
                else if (isPicked)
                  cls = "border-red-300 bg-red-50 text-red-600";
                else cls = "border-slate-200 bg-white text-slate-400";
              }
              return (
                <button
                  key={i}
                  onClick={() => choose(i)}
                  disabled={selected !== null}
                  className={`flex w-full items-center justify-between rounded-xl border px-4 py-3 text-left text-sm font-medium transition active:scale-[0.99] ${cls}`}
                >
                  <span>{opt}</span>
                  {selected !== null && isAnswer && <span>✓</span>}
                  {selected !== null && isPicked && !isAnswer && <span>✕</span>}
                </button>
              );
            })}
          </div>

          {selected !== null && (
            <div className="mt-4 animate-[fadeIn_0.3s_ease-out] rounded-xl bg-slate-50 p-3 text-xs leading-relaxed text-slate-600">
              <b>{selected === current.answer ? "✅ Correto! " : "💡 "}</b>
              {current.explain}
            </div>
          )}

          {selected !== null && (
            <Button onClick={next} className="mt-4 w-full">
              {step + 1 >= deck.length ? "Ver resultado 🏁" : "Próxima →"}
            </Button>
          )}
        </Card>
      </div>
    );
  }

  /* ---------------------------- RESULT ----------------------------- */
  return <Result deck={deck} score={score} stats={stats} onRestart={() => setScreen("start")} />;
}

/* --------------------------- result view --------------------------- */

function Result({
  deck,
  score,
  stats,
  onRestart,
}: {
  deck: Question[];
  score: number;
  stats: Stats;
  onRestart: () => void;
}) {
  const pct = useMemo(
    () => (deck.length ? Math.round((score / deck.length) * 100) : 0),
    [deck.length, score],
  );
  const medal = getMedal(pct);
  const isRecord = pct >= stats.bestPct && pct > 0;

  return (
    <div className="space-y-6">
      <SectionTitle emoji="🏁" title="Resultado" />

      <Card className="overflow-hidden text-center">
        <div className="animate-[pop_0.4s_ease-out] text-6xl">{medal.emoji}</div>
        <h3 className="mt-3 text-xl font-extrabold text-slate-900">
          {medal.title}
        </h3>
        <p className="text-sm text-slate-500">{medal.desc}</p>

        {isRecord && (
          <span className="mt-3 inline-block animate-[fadeIn_0.5s_ease-out] rounded-full bg-amber-100 px-3 py-1 text-xs font-bold text-amber-700">
            🎉 Novo recorde!
          </span>
        )}

        <div className="mt-5 rounded-2xl bg-gradient-to-br from-emerald-50 to-blue-50 p-4">
          <p className="text-3xl font-extrabold text-emerald-600">{pct}%</p>
          <p className="text-sm text-slate-500">
            Você acertou {score} de {deck.length}
          </p>
        </div>

        <div className="mt-4 h-3 w-full overflow-hidden rounded-full bg-slate-100">
          <div
            className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-blue-600 transition-all duration-700 ease-out"
            style={{ width: `${pct}%` }}
          />
        </div>

        <Button onClick={onRestart} className="mt-6 w-full">
          Jogar novamente 🔄
        </Button>
      </Card>

      <p className="text-center text-xs text-slate-400">
        Seu recorde de {stats.bestPct}% fica salvo neste dispositivo.
      </p>
    </div>
  );
}
