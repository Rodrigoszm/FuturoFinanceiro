import { useMemo, useState } from "react";
import { SectionTitle } from "../components/ui/SectionTitle";
import { Card } from "../components/ui/Card";
import { Modal } from "../components/ui/Modal";
import { useLocalStorage } from "../hooks/useLocalStorage";
import {
  TERMS,
  TERM_CATEGORIES,
  type Term,
  type TermCategory,
} from "../data/dicionario";

type Filter = "todos" | "favoritos" | TermCategory;

export function Dicionario() {
  const [favorites, setFavorites] = useLocalStorage<string[]>(
    "ff_dict_favorites",
    [],
  );
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<Filter>("todos");
  const [active, setActive] = useState<Term | null>(null);

  function toggleFav(id: string) {
    setFavorites((prev) =>
      prev.includes(id) ? prev.filter((f) => f !== id) : [...prev, id],
    );
  }

  const isFav = (id: string) => favorites.includes(id);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return TERMS.filter((t) => {
      // filtro
      if (filter === "favoritos" && !isFav(t.id)) return false;
      if (filter !== "todos" && filter !== "favoritos" && t.category !== filter)
        return false;
      // busca
      if (!q) return true;
      return (
        t.abbr.toLowerCase().includes(q) ||
        t.name.toLowerCase().includes(q) ||
        t.short.toLowerCase().includes(q)
      );
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query, filter, favorites]);

  const FILTERS: { id: Filter; label: string; emoji: string }[] = [
    { id: "todos", label: "Todos", emoji: "📚" },
    { id: "favoritos", label: "Favoritos", emoji: "⭐" },
    ...TERM_CATEGORIES.map((c) => ({ id: c.id, label: c.label, emoji: c.emoji })),
  ];

  return (
    <div className="space-y-5">
      <SectionTitle
        emoji="📖"
        title="Dicionário Financeiro"
        subtitle="Entenda os principais termos do mundo das finanças."
      />

      {/* Search */}
      <div className="relative">
        <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">
          🔍
        </span>
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Buscar termo (ex.: CDI, Selic...)"
          className="w-full rounded-xl border border-slate-200 bg-white py-3 pl-10 pr-10 text-sm outline-none transition focus:border-emerald-400 focus:ring-2 focus:ring-emerald-100"
        />
        {query && (
          <button
            onClick={() => setQuery("")}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
          >
            ✕
          </button>
        )}
      </div>

      {/* Filters */}
      <div className="-mx-4 overflow-x-auto px-4 pb-1">
        <div className="flex gap-2">
          {FILTERS.map((f) => {
            const on = filter === f.id;
            return (
              <button
                key={f.id}
                onClick={() => setFilter(f.id)}
                className={`flex shrink-0 items-center gap-1.5 rounded-full px-3.5 py-2 text-sm font-semibold transition ${
                  on
                    ? "bg-gradient-to-r from-emerald-500 to-blue-600 text-white shadow-md shadow-emerald-200"
                    : "border border-slate-200 bg-white text-slate-600 hover:bg-slate-50"
                }`}
              >
                <span>{f.emoji}</span>
                {f.label}
                {f.id === "favoritos" && favorites.length > 0 && (
                  <span
                    className={`ml-0.5 rounded-full px-1.5 text-xs ${
                      on ? "bg-white/25" : "bg-amber-100 text-amber-700"
                    }`}
                  >
                    {favorites.length}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* List */}
      {filtered.length > 0 ? (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          {filtered.map((t) => (
            <Card key={t.id} className="flex items-center gap-3 !py-3">
              <button
                onClick={() => setActive(t)}
                className="flex min-w-0 flex-1 items-center gap-3 text-left"
              >
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-blue-600 text-xs font-extrabold text-white shadow">
                  {t.abbr}
                </span>
                <span className="min-w-0">
                  <span className="block font-semibold text-slate-900">
                    {t.name}
                  </span>
                  <span className="block truncate text-xs text-slate-500">
                    {t.short}
                  </span>
                </span>
              </button>
              <button
                onClick={() => toggleFav(t.id)}
                aria-label="Favoritar"
                className="shrink-0 text-xl transition active:scale-90"
              >
                {isFav(t.id) ? "⭐" : "☆"}
              </button>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="text-center text-sm text-slate-400">
          {filter === "favoritos"
            ? "Você ainda não favoritou nenhum termo. Toque em ☆ para salvar!"
            : "Nenhum termo encontrado. 🔍"}
        </Card>
      )}

      {/* Modal */}
      <Modal
        open={active !== null}
        onClose={() => setActive(null)}
        title={active ? `${active.abbr} — ${active.name}` : ""}
      >
        {active && (
          <div className="space-y-4 pb-2">
            <button
              onClick={() => toggleFav(active.id)}
              className={`flex w-full items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-semibold transition ${
                isFav(active.id)
                  ? "bg-amber-100 text-amber-700"
                  : "bg-slate-100 text-slate-600"
              }`}
            >
              {isFav(active.id) ? "⭐ Nos favoritos" : "☆ Adicionar aos favoritos"}
            </button>

            <div className="rounded-2xl bg-gradient-to-br from-emerald-50 to-blue-50 p-4 text-sm font-medium text-slate-700">
              {active.short}
            </div>

            <div>
              <h4 className="font-bold text-slate-900">O que é</h4>
              <p className="mt-1 text-sm leading-relaxed text-slate-600">
                {active.full}
              </p>
            </div>

            <div>
              <h4 className="font-bold text-slate-900">Exemplo prático 🇧🇷</h4>
              <p className="mt-1 text-sm leading-relaxed text-slate-600">
                {active.example}
              </p>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
