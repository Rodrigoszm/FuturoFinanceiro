import { useMemo, useState } from "react";
import { SectionTitle } from "../components/ui/SectionTitle";
import { Card } from "../components/ui/Card";
import { Button } from "../components/ui/Button";
import { DonutChart } from "../components/finance/DonutChart";
import { useLocalStorage } from "../hooks/useLocalStorage";
import {
  CATEGORIES,
  CHART_COLORS,
  brl,
  formatDate,
  getCategory,
  type Transaction,
  type TxType,
} from "../data/financeData";

const SEED: Transaction[] = [
  { id: "s1", type: "in",  description: "Salário",             value: 3500, category: "salario",     date: new Date().toISOString() },
  { id: "s2", type: "out", description: "Aluguel",             value: 1200, category: "aluguel",     date: new Date().toISOString() },
  { id: "s3", type: "out", description: "Compras Supermercado",value: 480,  category: "supermercado",date: new Date().toISOString() },
  { id: "s4", type: "in",  description: "Freelance",           value: 600,  category: "freelance",   date: new Date().toISOString() },
  { id: "s5", type: "out", description: "Uber / Transporte",   value: 90,   category: "uber",        date: new Date().toISOString() },
];

export function MeuDinheiro() {
  const [txs, setTxs] = useLocalStorage<Transaction[]>("ff_transactions", SEED);
  const [formOpen, setFormOpen] = useState(false);

  /* ---- derived totals (auto balance) ---- */
  const { income, expense, balance } = useMemo(() => {
    let income = 0;
    let expense = 0;
    for (const t of txs) {
      if (t.type === "in") income += t.value;
      else expense += t.value;
    }
    return { income, expense, balance: income - expense };
  }, [txs]);

  /* ---- expense breakdown for chart ---- */
  const chartData = useMemo(() => {
    const map = new Map<string, number>();
    for (const t of txs) {
      if (t.type === "out") {
        map.set(t.category, (map.get(t.category) ?? 0) + t.value);
      }
    }
    return Array.from(map.entries())
      .map(([cat, value]) => ({
        label: getCategory(cat)?.label ?? "Outros",
        value,
        color: CHART_COLORS[cat] ?? "#94a3b8",
      }))
      .sort((a, b) => b.value - a.value);
  }, [txs]);

  function addTx(tx: Omit<Transaction, "id" | "date">) {
    setTxs((prev) => [
      { ...tx, id: crypto.randomUUID(), date: new Date().toISOString() },
      ...prev,
    ]);
    setFormOpen(false);
  }

  function removeTx(id: string) {
    setTxs((prev) => prev.filter((t) => t.id !== id));
  }

  return (
    <div className="space-y-6">
      <SectionTitle
        emoji="💰"
        title="Meu Dinheiro"
        subtitle="Controle entradas, saídas e veja para onde vai seu dinheiro."
      />

      {/* Balance card */}
      <Card className="relative overflow-hidden bg-gradient-to-br from-emerald-600 to-blue-700 text-white shadow-lg shadow-emerald-200/60">
        <div className="pointer-events-none absolute -right-8 -top-8 h-32 w-32 rounded-full bg-white/10 blur-2xl" />
        <p className="text-sm text-white/80">Saldo atual</p>
        <p className="text-3xl font-extrabold">{brl(balance)}</p>
        <div className="mt-4 flex gap-3 text-sm">
          <div className="flex-1 rounded-xl bg-white/15 p-3 backdrop-blur">
            <p className="text-xs text-white/70">↑ Entradas</p>
            <p className="font-bold">{brl(income)}</p>
          </div>
          <div className="flex-1 rounded-xl bg-white/15 p-3 backdrop-blur">
            <p className="text-xs text-white/70">↓ Saídas</p>
            <p className="font-bold">{brl(expense)}</p>
          </div>
        </div>
      </Card>

      <Button onClick={() => setFormOpen(true)} className="w-full">
        + Nova movimentação
      </Button>

      {/* Chart */}
      {chartData.length > 0 && (
        <Card>
          <h3 className="mb-4 font-bold text-slate-900">Gastos por categoria</h3>
          <DonutChart data={chartData} total={expense} />
        </Card>
      )}

      {/* History */}
      <section>
        <h3 className="mb-3 text-sm font-bold uppercase tracking-wide text-slate-400">
          Histórico ({txs.length})
        </h3>
        <div className="space-y-2">
          {txs.map((t) => {
            const cat = getCategory(t.category);
            return (
              <Card key={t.id} className="!py-3">
                <div className="flex items-center gap-3">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-slate-100 text-lg">
                    {cat?.emoji ?? "💸"}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-semibold text-slate-800">
                      {t.description}
                    </p>
                    <p className="text-xs text-slate-400">
                      {cat?.label ?? "Outros"} · {formatDate(t.date)}
                    </p>
                  </div>
                  <p
                    className={`shrink-0 font-bold ${
                      t.type === "in" ? "text-emerald-600" : "text-rose-500"
                    }`}
                  >
                    {t.type === "in" ? "+" : "-"}
                    {brl(t.value)}
                  </p>
                  <button
                    onClick={() => removeTx(t.id)}
                    aria-label="Remover"
                    className="shrink-0 text-slate-300 transition hover:text-rose-400"
                  >
                    ✕
                  </button>
                </div>
              </Card>
            );
          })}
          {txs.length === 0 && (
            <Card className="text-center text-sm text-slate-400">
              Nenhuma movimentação ainda. Adicione a primeira! 👆
            </Card>
          )}
        </div>
      </section>

      <p className="text-center text-xs text-slate-400">
        Seus dados ficam salvos apenas neste dispositivo.
      </p>

      {formOpen && (
        <TransactionForm onClose={() => setFormOpen(false)} onSave={addTx} />
      )}
    </div>
  );
}

/* ----------------------------- Form ----------------------------- */

function TransactionForm({
  onClose,
  onSave,
}: {
  onClose: () => void;
  onSave: (tx: Omit<Transaction, "id" | "date">) => void;
}) {
  const [type, setType]           = useState<TxType>("out");
  const [category, setCategory]   = useState("");
  const [description, setDescription] = useState("");
  const [value, setValue]         = useState("");
  // validation feedback
  const [tried, setTried]         = useState(false);

  const available = CATEGORIES.filter((c) => c.type === type);

  /* Auto-preenche a descrição ao clicar em uma categoria.
     Se o usuário já editou a descrição manualmente, respeita o texto dele. */
  function pickCategory(cat: typeof CATEGORIES[0]) {
    setCategory(cat.id);
    // apenas substitui se estiver vazio ou for uma autoDescription anterior
    setDescription((prev) => {
      const wasAuto = available.some((c) => c.autoDescription === prev);
      if (!prev || wasAuto) return cat.autoDescription;
      return prev;
    });
  }

  function switchType(t: TxType) {
    setType(t);
    setCategory("");
    setDescription("");
    setTried(false);
  }

  const numValue = Number(value.replace(",", "."));
  const missingCategory = !category;
  const missingValue    = !numValue || numValue <= 0;

  function submit(e: React.FormEvent) {
    e.preventDefault();
    setTried(true);
    if (missingCategory || missingValue) return;
    onSave({
      type,
      description: description.trim() || (getCategory(category)?.autoDescription ?? ""),
      value: numValue,
      category,
    });
  }

  const inputCls =
    "w-full rounded-xl border bg-slate-50 px-3 py-2.5 text-sm outline-none transition focus:bg-white focus:ring-2";

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center">
      {/* overlay */}
      <div
        onClick={onClose}
        className="absolute inset-0 animate-[fadeIn_0.2s_ease-out] bg-slate-900/50 backdrop-blur-sm"
      />

      <form
        onSubmit={submit}
        className="relative flex max-h-[92vh] w-full flex-col overflow-hidden rounded-t-3xl bg-white shadow-2xl animate-[fadeIn_0.25s_ease-out] sm:max-w-md sm:rounded-3xl"
      >
        {/* drag handle */}
        <div className="flex justify-center pt-3 sm:hidden">
          <span className="h-1.5 w-10 rounded-full bg-slate-200" />
        </div>

        {/* header */}
        <div className="flex items-center justify-between px-5 py-4">
          <h3 className="text-lg font-bold text-slate-900">Nova movimentação</h3>
          <button
            type="button"
            onClick={onClose}
            className="flex h-9 w-9 items-center justify-center rounded-full bg-slate-100 text-slate-500 transition hover:bg-slate-200"
          >
            ✕
          </button>
        </div>

        {/* scrollable body */}
        <div className="flex-1 space-y-5 overflow-y-auto overscroll-contain px-5 pb-4">

          {/* ── Tipo ── */}
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => switchType("in")}
              className={`flex-1 rounded-xl py-2.5 text-sm font-bold transition active:scale-[0.98] ${
                type === "in"
                  ? "bg-emerald-500 text-white shadow-md shadow-emerald-200"
                  : "bg-slate-100 text-slate-400 hover:bg-slate-200"
              }`}
            >
              ↑ Receita
            </button>
            <button
              type="button"
              onClick={() => switchType("out")}
              className={`flex-1 rounded-xl py-2.5 text-sm font-bold transition active:scale-[0.98] ${
                type === "out"
                  ? "bg-rose-500 text-white shadow-md shadow-rose-200"
                  : "bg-slate-100 text-slate-400 hover:bg-slate-200"
              }`}
            >
              ↓ Despesa
            </button>
          </div>

          {/* ── Categorias ── */}
          <div>
            <div className="mb-2 flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wide text-slate-500">
                Categoria
              </span>
              {tried && missingCategory && (
                <span className="text-[11px] font-semibold text-rose-500">
                  Selecione uma categoria
                </span>
              )}
            </div>
            <div className="grid grid-cols-4 gap-2">
              {available.map((cat) => {
                const on = category === cat.id;
                return (
                  <button
                    type="button"
                    key={cat.id}
                    onClick={() => pickCategory(cat)}
                    className={`flex flex-col items-center gap-1.5 rounded-2xl border-2 p-2 text-center transition active:scale-[0.96] ${
                      on
                        ? "border-transparent shadow-md"
                        : "border-slate-100 bg-white hover:border-slate-200 hover:bg-slate-50"
                    }`}
                    style={
                      on
                        ? { backgroundColor: cat.hex + "18", borderColor: cat.hex }
                        : {}
                    }
                  >
                    <span className="text-2xl leading-none">{cat.emoji}</span>
                    <span
                      className="w-full truncate text-[10px] font-semibold leading-tight"
                      style={on ? { color: cat.hex } : { color: "#64748b" }}
                    >
                      {cat.label}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* ── Descrição ── */}
          <div>
            <label className="mb-1 block text-xs font-bold uppercase tracking-wide text-slate-500">
              Descrição
            </label>
            <input
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Ex.: Salário, Conta de Luz..."
              className={`${inputCls} border-slate-200 focus:border-emerald-400 focus:ring-emerald-100`}
            />
          </div>

          {/* ── Valor ── */}
          <div>
            <div className="mb-1 flex items-center justify-between">
              <label className="text-xs font-bold uppercase tracking-wide text-slate-500">
                Valor (R$)
              </label>
              {tried && missingValue && (
                <span className="text-[11px] font-semibold text-rose-500">
                  Informe o valor
                </span>
              )}
            </div>
            <div className="relative">
              <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-sm font-bold text-slate-400">
                R$
              </span>
              <input
                type="number"
                inputMode="decimal"
                min="0"
                step="0.01"
                value={value}
                onChange={(e) => setValue(e.target.value)}
                placeholder="0,00"
                className={`${inputCls} pl-9 text-base font-bold ${
                  tried && missingValue
                    ? "border-rose-300 focus:border-rose-400 focus:ring-rose-100"
                    : "border-slate-200 focus:border-emerald-400 focus:ring-emerald-100"
                }`}
              />
            </div>
          </div>
        </div>

        {/* ── Footer ── */}
        <div
          className="border-t border-slate-100 px-5 pt-3"
          style={{ paddingBottom: "max(env(safe-area-inset-bottom), 1rem)" }}
        >
          <Button
            type="submit"
            className={`w-full transition ${
              type === "out"
                ? "!from-rose-500 !to-rose-600 !shadow-rose-200"
                : ""
            }`}
          >
            {type === "in" ? "↑ Salvar receita" : "↓ Salvar despesa"}
          </Button>
        </div>
      </form>
    </div>
  );
}
