/**
 * LoginPage — tela de entrada premium do Futuro Financeiro.
 *
 * Exibida ANTES do app principal quando o usuário não está autenticado.
 * Após login bem-sucedido, o AuthGate libera o app automaticamente.
 *
 * Recursos:
 *  - Fundo verde escuro elegante com glows dourados
 *  - Logo FF centralizado
 *  - Toggle suave entre "Entrar" e "Cadastrar"
 *  - 3 botões claros: Entrar, Cadastrar, Entrar como visitante
 *  - Feedback de carregamento e erros
 *  - Totalmente responsivo
 */
import { useState } from "react";
import { Logo } from "../components/brand/Logo";
import { useAuth } from "../auth/AuthContext";

type Mode = "login" | "signup";

export function LoginPage() {
  const { login, signup } = useAuth();

  const [mode, setMode] = useState<Mode>("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  function switchMode(next: Mode) {
    setMode(next);
    setError(null);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const res =
        mode === "login"
          ? await login(email, password)
          : await signup(name, email, password);
      if (!res.ok) setError(res.error ?? "Algo deu errado.");
      // Em caso de sucesso, o AuthGate troca automaticamente para o app.
    } finally {
      setSubmitting(false);
    }
  }

  async function handleGuest() {
    setError(null);
    setSubmitting(true);
    try {
      const demoEmail = "visitante@futuro.com";
      const r = await login(demoEmail, "1234");
      if (!r.ok) {
        const s = await signup("Visitante", demoEmail, "1234");
        if (!s.ok) setError(s.error ?? "Não foi possível entrar como visitante.");
      }
    } finally {
      setSubmitting(false);
    }
  }

  const inputCls =
    "w-full rounded-xl border border-white/15 bg-white/10 px-4 py-3 text-sm text-white placeholder-white/50 outline-none transition focus:border-amber-300/60 focus:bg-white/15 focus:ring-2 focus:ring-amber-300/20";

  return (
    <div className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden bg-gradient-to-br from-emerald-950 via-emerald-900 to-emerald-950 px-5 py-10 text-white">
      {/* glows decorativos (estáticos) */}
      <div className="pointer-events-none absolute left-1/2 top-1/3 h-[420px] w-[420px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-amber-400/15 blur-3xl" />
      <div className="pointer-events-none absolute -left-20 top-12 h-40 w-40 rounded-full bg-emerald-400/10 blur-2xl" />
      <div className="pointer-events-none absolute -right-16 bottom-12 h-48 w-48 rounded-full bg-amber-300/10 blur-2xl" />
      <div className="pointer-events-none absolute inset-x-12 top-1/2 h-px bg-gradient-to-r from-transparent via-amber-400/40 to-transparent" />

      <div className="relative w-full max-w-sm splash-enter">
        {/* Brand */}
        <div className="text-center">
          <div className="inline-flex">
            <Logo size="xl" />
          </div>
          <h1
            className="mt-5 text-3xl font-extrabold tracking-tight"
            style={{ fontFamily: "Georgia, 'Times New Roman', serif" }}
          >
            Futuro{" "}
            <span className="bg-gradient-to-b from-amber-200 via-amber-400 to-amber-600 bg-clip-text text-transparent">
              Financeiro
            </span>
          </h1>
          <p className="mt-2 text-[11px] font-semibold uppercase tracking-[0.3em] text-amber-300/80">
            Planeje · Controle · Conquiste
          </p>
        </div>

        {/* Card */}
        <div className="mt-7 rounded-3xl border border-white/10 bg-white/[0.06] p-5 shadow-2xl shadow-emerald-950/40 backdrop-blur-xl">
          {/* Mode toggle */}
          <div className="mb-4 flex gap-1 rounded-xl bg-white/5 p-1">
            <button
              type="button"
              onClick={() => switchMode("login")}
              className={`flex-1 rounded-lg py-2 text-sm font-semibold transition ${
                mode === "login"
                  ? "bg-gradient-to-r from-amber-400 to-amber-500 text-emerald-950 shadow"
                  : "text-white/60 hover:text-white"
              }`}
            >
              Entrar
            </button>
            <button
              type="button"
              onClick={() => switchMode("signup")}
              className={`flex-1 rounded-lg py-2 text-sm font-semibold transition ${
                mode === "signup"
                  ? "bg-gradient-to-r from-amber-400 to-amber-500 text-emerald-950 shadow"
                  : "text-white/60 hover:text-white"
              }`}
            >
              Cadastrar
            </button>
          </div>

          <form className="space-y-3" onSubmit={handleSubmit} key={mode}>
            {mode === "signup" && (
              <input
                autoFocus
                className={inputCls}
                placeholder="Nome completo"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            )}
            <input
              className={inputCls}
              type="email"
              placeholder="E-mail"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="email"
            />
            <input
              className={inputCls}
              type="password"
              placeholder="Senha"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete={mode === "login" ? "current-password" : "new-password"}
            />

            {error && (
              <p className="rounded-xl border border-rose-400/30 bg-rose-500/10 px-3 py-2 text-xs font-medium text-rose-200">
                ⚠️ {error}
              </p>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-amber-400 via-amber-400 to-amber-500 px-4 py-3 text-sm font-bold text-emerald-950 shadow-lg shadow-amber-500/20 transition hover:brightness-110 active:scale-[0.99] disabled:opacity-60"
            >
              {submitting ? (
                <>
                  <span className="h-4 w-4 animate-spin rounded-full border-2 border-emerald-950 border-t-transparent" />
                  Aguarde...
                </>
              ) : mode === "login" ? (
                "Entrar →"
              ) : (
                "Criar conta"
              )}
            </button>
          </form>

          {/* Divider */}
          <div className="my-4 flex items-center gap-3 text-xs text-white/30">
            <div className="h-px flex-1 bg-white/10" />
            ou
            <div className="h-px flex-1 bg-white/10" />
          </div>

          {/* Guest */}
          <button
            type="button"
            onClick={handleGuest}
            disabled={submitting}
            className="flex w-full items-center justify-center gap-2 rounded-xl border border-white/15 bg-transparent px-4 py-3 text-sm font-semibold text-white transition hover:bg-white/5 active:scale-[0.99] disabled:opacity-60"
          >
            🚀 Entrar como visitante
          </button>
        </div>

        <p className="mt-5 text-center text-[11px] text-white/50">
          Ao continuar você concorda com os termos do Futuro Financeiro.
        </p>
      </div>
    </div>
  );
}
