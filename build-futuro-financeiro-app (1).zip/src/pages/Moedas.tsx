import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { SectionTitle } from "../components/ui/SectionTitle";
import { Card } from "../components/ui/Card";
import { fetchQuotes, type AssetQuote } from "../data/economiaApi";
import { buildNews } from "../data/economiaNews";
import { Loading } from "../components/brand/Loading";

const REFRESH_MS = 60_000; // atualização automática a cada 60s

function brl(n: number, max = 2) {
  return n.toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
    maximumFractionDigits: max,
  });
}

export function Moedas() {
  const [quotes, setQuotes] = useState<AssetQuote[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const timer = useRef<number | null>(null);

  const load = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const data = await fetchQuotes();
      setQuotes(data);
      setError(false);
      setLastUpdate(new Date());
    } catch {
      setError(true);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    timer.current = window.setInterval(() => load(true), REFRESH_MS);
    return () => {
      if (timer.current) window.clearInterval(timer.current);
    };
  }, [load]);

  const news = useMemo(() => buildNews(quotes), [quotes]);

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <SectionTitle
          emoji="📊"
          title="Central Econômica"
          subtitle="Cotações em tempo real com atualização automática."
        />
        <button
          onClick={() => load()}
          className="mt-1 flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-slate-100 text-slate-500 transition hover:bg-slate-200 active:scale-95"
          aria-label="Atualizar"
        >
          <span className={loading ? "inline-block animate-spin" : ""}>↻</span>
        </button>
      </div>

      {/* status line */}
      <div className="flex items-center gap-2 text-xs text-slate-400">
        <span className="relative flex h-2 w-2">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
          <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
        </span>
        {error
          ? "Sem conexão com a API"
          : lastUpdate
            ? `Atualizado às ${lastUpdate.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })} · auto a cada 60s`
            : "Carregando..."}
      </div>

      {error && quotes.length === 0 && (
        <Card className="text-center text-sm text-slate-500">
          ⚠️ Não foi possível carregar as cotações agora.
          <button
            onClick={() => load()}
            className="mt-2 block w-full font-semibold text-emerald-600"
          >
            Tentar novamente
          </button>
        </Card>
      )}

      {/* loading */}
      {loading && quotes.length === 0 && (
        <Loading label="Buscando cotações..." />
      )}

      {/* asset cards */}
      {quotes.length > 0 && (
        <div className="grid grid-cols-2 gap-3">
          {quotes.map((q, idx) => {
            const up = q.pctChange >= 0;
            const wide = idx === quotes.length - 1 && quotes.length % 2 !== 0;
            return (
              <Card
                key={q.code}
                className={`relative overflow-hidden ${wide ? "col-span-2" : ""}`}
              >
                <div className="flex items-center justify-between">
                  <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-100 text-lg">
                    {q.emoji}
                  </span>
                  <span
                    className={`flex items-center gap-0.5 rounded-full px-2 py-1 text-xs font-bold ${
                      up
                        ? "bg-emerald-50 text-emerald-600"
                        : "bg-rose-50 text-rose-500"
                    }`}
                  >
                    {up ? "▲" : "▼"} {Math.abs(q.pctChange).toFixed(2)}%
                  </span>
                </div>
                <p className="mt-3 text-sm font-semibold text-slate-500">
                  {q.code}
                </p>
                <p className="text-lg font-extrabold text-slate-900">
                  {brl(q.value, q.value >= 1000 ? 0 : 2)}
                </p>
                <div className="mt-1 flex gap-2 text-[10px] text-slate-400">
                  <span>↑ {brl(q.high, q.high >= 1000 ? 0 : 2)}</span>
                  <span>↓ {brl(q.low, q.low >= 1000 ? 0 : 2)}</span>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {/* mini news */}
      {news.length > 0 && (
        <section>
          <h3 className="mb-3 text-sm font-bold uppercase tracking-wide text-slate-400">
            📰 Giro do mercado
          </h3>
          <div className="space-y-2">
            {news.map((n, i) => (
              <Card key={i} className="!py-3">
                <div className="flex items-center gap-3">
                  <span className="text-lg">{n.emoji}</span>
                  <p className="flex-1 text-sm text-slate-700">{n.text}</p>
                  <span
                    className={`text-xs font-bold ${
                      n.tone === "up"
                        ? "text-emerald-600"
                        : n.tone === "down"
                          ? "text-rose-500"
                          : "text-slate-400"
                    }`}
                  >
                    {n.tone === "up" ? "📈" : n.tone === "down" ? "📉" : "➖"}
                  </span>
                </div>
              </Card>
            ))}
          </div>
        </section>
      )}

      <p className="text-center text-xs text-slate-400">
        Fonte: AwesomeAPI · Valores em Real (BRL). Apenas para fins educativos.
      </p>
    </div>
  );
}
