import { useState } from "react";
import { Card } from "../components/ui/Card";
import { SectionTitle } from "../components/ui/SectionTitle";
import { Modal } from "../components/ui/Modal";

interface Section {
  heading: string;
  text: string;
}

interface Topic {
  id: string;
  emoji: string;
  title: string;
  short: string;
  gradient: string;
  intro: string;
  sections: Section[];
}

const TOPICS: Topic[] = [
  {
    id: "porcentagem",
    emoji: "％",
    title: "Porcentagem",
    short: "A base de tudo em finanças.",
    gradient: "from-emerald-500 to-teal-600",
    intro:
      "Porcentagem é uma forma de representar uma parte de um total dividido em 100. Entender isso é o primeiro passo para dominar descontos, juros e investimentos.",
    sections: [
      {
        heading: "Como calcular",
        text: "Para achar 10% de um valor, basta dividir por 10. Para 20%, divida por 5. Em geral: multiplique o valor pela porcentagem e divida por 100.",
      },
      {
        heading: "Exemplo real (Brasil)",
        text: "Uma TV custa R$ 2.000 e está com 15% de desconto à vista. O desconto é 2.000 × 15 ÷ 100 = R$ 300. Você paga R$ 1.700.",
      },
      {
        heading: "No dia a dia",
        text: "Gorjeta de 10% no restaurante, 30% de desconto na Black Friday ou o aumento de 4,5% no salário — tudo é porcentagem.",
      },
    ],
  },
  {
    id: "juros-simples",
    emoji: "➕",
    title: "Juros Simples",
    short: "Juros sempre sobre o valor inicial.",
    gradient: "from-blue-500 to-indigo-600",
    intro:
      "Nos juros simples, a taxa incide sempre sobre o valor original (o capital). Eles não acumulam sobre os juros já cobrados.",
    sections: [
      {
        heading: "A fórmula",
        text: "Juros = Capital × Taxa × Tempo. Simples assim: a cada período, o mesmo valor de juros é somado.",
      },
      {
        heading: "Exemplo real (Brasil)",
        text: "Você empresta R$ 1.000 a um amigo a 2% ao mês de juros simples por 5 meses. Juros = 1.000 × 0,02 × 5 = R$ 100. Ele devolve R$ 1.100.",
      },
      {
        heading: "Onde aparece",
        text: "Alguns parcelamentos e multas por atraso usam juros simples. É menos comum no mercado do que os juros compostos.",
      },
    ],
  },
  {
    id: "juros-compostos",
    emoji: "📈",
    title: "Juros Compostos",
    short: "Juros sobre juros: o efeito bola de neve.",
    gradient: "from-teal-500 to-emerald-600",
    intro:
      "Nos juros compostos, os juros de cada período passam a render também. É o motor dos investimentos — e o vilão das dívidas de cartão.",
    sections: [
      {
        heading: "Como funciona",
        text: "Cada período, a taxa incide sobre o valor total acumulado (capital + juros anteriores). O crescimento é exponencial.",
      },
      {
        heading: "Exemplo real (Brasil)",
        text: "Investindo R$ 200 por mês no Tesouro Selic a ~0,9% ao mês, em 20 anos você acumularia muito mais do que o total aportado — a maior parte vinda dos juros.",
      },
      {
        heading: "Lição de ouro",
        text: "Quanto mais cedo você começa, mais o tempo trabalha a seu favor. Comece pequeno, mas comece hoje.",
      },
    ],
  },
  {
    id: "cartao",
    emoji: "💳",
    title: "Cartão de Crédito",
    short: "Use a favor, nunca contra você.",
    gradient: "from-rose-500 to-pink-600",
    intro:
      "O cartão é uma ferramenta poderosa, mas o crédito rotativo tem um dos juros mais altos do Brasil. Saber usar faz toda a diferença.",
    sections: [
      {
        heading: "O perigo do rotativo",
        text: "Se você paga só o mínimo da fatura, o restante entra no rotativo, que pode passar de 400% ao ano. A dívida cresce muito rápido.",
      },
      {
        heading: "Exemplo real (Brasil)",
        text: "Fatura de R$ 1.000 e você paga só R$ 150. Os R$ 850 restantes podem virar mais de R$ 1.200 em poucos meses por causa dos juros.",
      },
      {
        heading: "Como usar bem",
        text: "Pague sempre a fatura integral, aproveite o prazo de até 40 dias sem juros e use programas de pontos/cashback como bônus, não como desculpa para gastar mais.",
      },
    ],
  },
  {
    id: "economia",
    emoji: "🐖",
    title: "Economia Diária",
    short: "Pequenos hábitos, grande diferença.",
    gradient: "from-amber-500 to-orange-600",
    intro:
      "Economizar não é sofrer — é fazer escolhas conscientes no dia a dia para sobrar dinheiro no fim do mês.",
    sections: [
      {
        heading: "O efeito cafezinho",
        text: "Um café de R$ 8 por dia útil dá cerca de R$ 176 por mês, mais de R$ 2.000 por ano. Pequenos gastos somam muito.",
      },
      {
        heading: "Exemplo real (Brasil)",
        text: "Trocar o delivery 3x por semana por marmita pode economizar de R$ 400 a R$ 600 por mês — dinheiro que pode ir direto para investimentos.",
      },
      {
        heading: "Dicas práticas",
        text: "Faça lista antes do mercado, compare preços em apps, aproveite o programa Nota Fiscal Paulista e evite compras por impulso esperando 24h antes de decidir.",
      },
    ],
  },
  {
    id: "investimentos",
    emoji: "🏦",
    title: "Investimentos Básicos",
    short: "Faça seu dinheiro trabalhar por você.",
    gradient: "from-violet-500 to-purple-600",
    intro:
      "Investir é deixar o dinheiro render em vez de ficar parado perdendo para a inflação. No Brasil há boas opções seguras para começar.",
    sections: [
      {
        heading: "Comece pela renda fixa",
        text: "Tesouro Selic, CDBs e LCIs/LCAs são seguros e simples. O Tesouro Selic é ótimo para a reserva de emergência por ter liquidez diária.",
      },
      {
        heading: "Exemplo real (Brasil)",
        text: "Com R$ 100 já dá para comprar um título do Tesouro Direto. Um CDB que paga 100% do CDI rende próximo da taxa Selic, com proteção do FGC até R$ 250 mil.",
      },
      {
        heading: "Cuidado com promessas",
        text: "Desconfie de retornos 'garantidos' muito altos. Poupança rende pouco; renda variável (ações, fundos) pode render mais, mas exige estudo e tolerância a risco.",
      },
    ],
  },
];

export function Aprender() {
  const [active, setActive] = useState<Topic | null>(null);

  return (
    <div className="space-y-6">
      <SectionTitle
        emoji="📚"
        title="Aprender"
        subtitle="Conceitos financeiros explicados de forma simples, com exemplos do Brasil."
      />

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        {TOPICS.map((t) => (
          <button
            key={t.id}
            onClick={() => setActive(t)}
            className="group flex items-center gap-4 rounded-2xl border border-slate-100 bg-white p-4 text-left shadow-sm shadow-slate-200/50 transition hover:-translate-y-0.5 hover:shadow-md active:scale-[0.99]"
          >
            <span
              className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br ${t.gradient} text-2xl text-white shadow-md`}
            >
              {t.emoji}
            </span>
            <span className="min-w-0 flex-1">
              <span className="block font-semibold text-slate-900">
                {t.title}
              </span>
              <span className="block text-xs text-slate-500">{t.short}</span>
              <span className="mt-1 inline-block text-xs font-semibold text-emerald-600 transition group-hover:translate-x-0.5">
                Estudar →
              </span>
            </span>
          </button>
        ))}
      </div>

      <Card className="bg-gradient-to-br from-slate-50 to-emerald-50">
        <p className="text-sm text-slate-600">
          💡 Dica: estude um tópico por dia. Em uma semana você domina o básico
          das finanças pessoais!
        </p>
      </Card>

      {/* Topic detail modal */}
      <Modal
        open={active !== null}
        onClose={() => setActive(null)}
        title={active ? `${active.emoji} ${active.title}` : ""}
      >
        {active && (
          <div className="space-y-4 pb-2">
            <div
              className={`rounded-2xl bg-gradient-to-br ${active.gradient} p-4 text-sm font-medium leading-relaxed text-white`}
            >
              {active.intro}
            </div>
            {active.sections.map((s, i) => (
              <div key={i}>
                <h4 className="font-bold text-slate-900">{s.heading}</h4>
                <p className="mt-1 text-sm leading-relaxed text-slate-600">
                  {s.text}
                </p>
              </div>
            ))}
          </div>
        )}
      </Modal>
    </div>
  );
}
