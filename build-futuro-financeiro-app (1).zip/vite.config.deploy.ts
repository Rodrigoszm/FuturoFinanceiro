/**
 * vite.config.deploy.ts
 *
 * Config de build para DEPLOY (Vercel / GitHub Pages / produção).
 *
 * Diferença do vite.config.ts principal:
 *  - Remove vite-plugin-singlefile (que inlina tudo em um único HTML)
 *  - Gera assets separados (JS, CSS, imagens) → necessário para PWA e Vercel
 *  - Habilita code-splitting e chunks otimizados
 *  - Define base URL como "/" para Vercel
 *
 * Uso:
 *   npm run build:deploy
 */
import path from "path";
import { fileURLToPath } from "url";
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default defineConfig({
  base: "/",

  plugins: [react(), tailwindcss()],

  resolve: {
    alias: {
      "@": path.resolve(__dirname, "src"),
    },
  },

  build: {
    outDir: "dist",
    emptyOutDir: true,
    sourcemap: false,

    rollupOptions: {
      output: {
        // Chunks separados para vendor, firebase e app principal
        manualChunks: {
          "vendor-react": ["react", "react-dom"],
          "vendor-firebase": ["firebase/app", "firebase/auth", "firebase/firestore"],
        },
        // Nomes de arquivo com hash para cache busting
        chunkFileNames: "assets/[name]-[hash].js",
        entryFileNames: "assets/[name]-[hash].js",
        assetFileNames: "assets/[name]-[hash].[ext]",
      },
    },

    // Aumenta o limite de aviso para chunks maiores (Firebase é grande)
    chunkSizeWarningLimit: 1000,
  },
});
