/* Futuro Financeiro — Service Worker
 * Estratégias:
 *  - Navegações (HTML): network-first, com fallback ao cache
 *  - Estáticos (mesmo origin): stale-while-revalidate
 *  - Skip waiting + claim para atualizar rápido
 */

const VERSION = "ff-v1.0.0";
const STATIC_CACHE = `ff-static-${VERSION}`;
const RUNTIME_CACHE = `ff-runtime-${VERSION}`;

const PRECACHE_URLS = [
  "./",
  "./index.html",
  "./manifest.webmanifest",
  "./icon-192.png",
  "./icon-512.png",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(STATIC_CACHE)
      .then((cache) => cache.addAll(PRECACHE_URLS).catch(() => {}))
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys
            .filter((k) => k !== STATIC_CACHE && k !== RUNTIME_CACHE)
            .map((k) => caches.delete(k)),
        ),
      )
      .then(() => self.clients.claim()),
  );
});

self.addEventListener("fetch", (event) => {
  const req = event.request;

  // Apenas GET
  if (req.method !== "GET") return;

  const url = new URL(req.url);

  // Não interceptar chamadas a APIs externas (deixa a rede fazer seu trabalho)
  if (url.origin !== self.location.origin) return;

  // Navegação (páginas HTML) → network-first
  if (req.mode === "navigate") {
    event.respondWith(
      fetch(req)
        .then((res) => {
          const copy = res.clone();
          caches.open(RUNTIME_CACHE).then((c) => c.put(req, copy));
          return res;
        })
        .catch(() =>
          caches.match(req).then((cached) => cached || caches.match("./index.html")),
        ),
    );
    return;
  }

  // Demais GETs do mesmo origin → stale-while-revalidate
  event.respondWith(
    caches.match(req).then((cached) => {
      const networkFetch = fetch(req)
        .then((res) => {
          if (res && res.status === 200) {
            const copy = res.clone();
            caches.open(RUNTIME_CACHE).then((c) => c.put(req, copy));
          }
          return res;
        })
        .catch(() => cached);
      return cached || networkFetch;
    }),
  );
});
