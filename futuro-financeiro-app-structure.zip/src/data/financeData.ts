export type TxType = "in" | "out";

export interface Transaction {
  id: string;
  type: TxType;
  description: string;
  value: number;
  category: string;
  date: string; // ISO string
}

export interface Category {
  id: string;
  label: string;
  emoji: string;
  color: string; // tailwind bg/text base color
  type: TxType;
}

export const CATEGORIES: Category[] = [
  // Entradas
  { id: "salario", label: "Salário", emoji: "💼", color: "emerald", type: "in" },
  { id: "freela", label: "Freela", emoji: "💻", color: "teal", type: "in" },
  { id: "investimento", label: "Rendimentos", emoji: "📈", color: "green", type: "in" },
  { id: "outros-in", label: "Outros", emoji: "➕", color: "lime", type: "in" },
  // Saídas
  { id: "moradia", label: "Moradia", emoji: "🏠", color: "blue", type: "out" },
  { id: "alimentacao", label: "Alimentação", emoji: "🍔", color: "orange", type: "out" },
  { id: "transporte", label: "Transporte", emoji: "🚗", color: "indigo", type: "out" },
  { id: "lazer", label: "Lazer", emoji: "🎮", color: "violet", type: "out" },
  { id: "saude", label: "Saúde", emoji: "💊", color: "rose", type: "out" },
  { id: "contas", label: "Contas", emoji: "🧾", color: "amber", type: "out" },
  { id: "outros-out", label: "Outros", emoji: "📦", color: "slate", type: "out" },
];

export function getCategory(id: string): Category | undefined {
  return CATEGORIES.find((c) => c.id === id);
}

// Cores fixas para o gráfico (hex) por categoria de saída
export const CHART_COLORS: Record<string, string> = {
  moradia: "#3b82f6",
  alimentacao: "#f97316",
  transporte: "#6366f1",
  lazer: "#8b5cf6",
  saude: "#f43f5e",
  contas: "#f59e0b",
  "outros-out": "#94a3b8",
};

export function brl(n: number) {
  return n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

export function formatDate(iso: string) {
  const d = new Date(iso);
  return d.toLocaleDateString("pt-BR", { day: "2-digit", month: "short" });
}
