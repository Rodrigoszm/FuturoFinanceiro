import { useMemo, useState } from "react";
import { SectionTitle } from "../components/ui/SectionTitle";
import { Card } from "../components/ui/Card";
import { Button } from "../components/ui/Button";
import { DonutChart } from "../components/finance/DonutChart";
import { useLocalStorage } from "../hooks/useLocalStorage";
import {
  CATEGORIES,
  CHART_COLORS,
  brl,
  formatDate,
  getCategory,
  type Transaction,
  type TxType,
} from "../data/financeData";

const SEED: Transaction[] = [
  { id: "s1", type: "in", description: "Salário", value: 3500, category: "salario", date: new Date().toISOString() },
  { id: "s2", type: "out", description: "Aluguel", value: 1200, category: "moradia", date: new Date().toISOString() },
  { id: "s3", type: "out", description: "Mercado", value: 480, category: "alimentacao", date: new Date().toISOString() },
  { id: "s4", type: "in", description: "Freela design", value: 600, category: "freela", date: new Date().toISOString() },
  { id: "s5", type: "out", description: "Uber", value: 90, category: "transporte", date: new Date().toISOString() },
];

export function MeuDinheiro() {
  const [txs, setTxs] = useLocalStorage<Transaction[]>("ff_transactions", SEED);
  const [formOpen, setFormOpen] = useState(false);

  /* ---- derived totals (auto balance) ---- */
  const { income, expense, balance } = useMemo(() => {
    let income = 0;
    let expense = 0;
    for (const t of txs) {
      if (t.type === "in") income += t.value;
      else expense += t.value;
    }
    return { income, expense, balance: income - expense };
  }, [txs]);

  /* ---- expense breakdown for chart ---- */
  const chartData = useMemo(() => {
    const map = new Map<string, number>();
    for (const t of txs) {
      if (t.type === "out") {
        map.set(t.category, (map.get(t.category) ?? 0) + t.value);
      }
    }
    return Array.from(map.entries())
      .map(([cat, value]) => ({
        label: getCategory(cat)?.label ?? "Outros",
        value,
        color: CHART_COLORS[cat] ?? "#94a3b8",
      }))
      .sort((a, b) => b.value - a.value);
  }, [txs]);

  function addTx(tx: Omit<Transaction, "id" | "date">) {
    setTxs((prev) => [
      { ...tx, id: crypto.randomUUID(), date: new Date().toISOString() },
      ...prev,
    ]);
    setFormOpen(false);
  }

  function removeTx(id: string) {
    setTxs((prev) => prev.filter((t) => t.id !== id));
  }

  return (
    <div className="space-y-6">
      <SectionTitle
        emoji="💰"
        title="Meu Dinheiro"
        subtitle="Controle entradas, saídas e veja para onde vai seu dinheiro."
      />

      {/* Balance card */}
      <Card className="relative overflow-hidden bg-gradient-to-br from-emerald-600 to-blue-700 text-white shadow-lg shadow-emerald-200/60">
        <div className="pointer-events-none absolute -right-8 -top-8 h-32 w-32 rounded-full bg-white/10 blur-2xl" />
        <p className="text-sm text-white/80">Saldo atual</p>
        <p className="text-3xl font-extrabold">{brl(balance)}</p>
        <div className="mt-4 flex gap-3 text-sm">
          <div className="flex-1 rounded-xl bg-white/15 p-3 backdrop-blur">
            <p className="text-xs text-white/70">↑ Entradas</p>
            <p className="font-bold">{brl(income)}</p>
          </div>
          <div className="flex-1 rounded-xl bg-white/15 p-3 backdrop-blur">
            <p className="text-xs text-white/70">↓ Saídas</p>
            <p className="font-bold">{brl(expense)}</p>
          </div>
        </div>
      </Card>

      <Button onClick={() => setFormOpen(true)} className="w-full">
        + Nova movimentação
      </Button>

      {/* Chart */}
      {chartData.length > 0 && (
        <Card>
          <h3 className="mb-4 font-bold text-slate-900">Gastos por categoria</h3>
          <DonutChart data={chartData} total={expense} />
        </Card>
      )}

      {/* History */}
      <section>
        <h3 className="mb-3 text-sm font-bold uppercase tracking-wide text-slate-400">
          Histórico ({txs.length})
        </h3>
        <div className="space-y-2">
          {txs.map((t) => {
            const cat = getCategory(t.category);
            return (
              <Card key={t.id} className="!py-3">
                <div className="flex items-center gap-3">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-slate-100 text-lg">
                    {cat?.emoji ?? "💸"}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-semibold text-slate-800">
                      {t.description}
                    </p>
                    <p className="text-xs text-slate-400">
                      {cat?.label ?? "Outros"} · {formatDate(t.date)}
                    </p>
                  </div>
                  <p
                    className={`shrink-0 font-bold ${
                      t.type === "in" ? "text-emerald-600" : "text-rose-500"
                    }`}
                  >
                    {t.type === "in" ? "+" : "-"}
                    {brl(t.value)}
                  </p>
                  <button
                    onClick={() => removeTx(t.id)}
                    aria-label="Remover"
                    className="shrink-0 text-slate-300 transition hover:text-rose-400"
                  >
                    ✕
                  </button>
                </div>
              </Card>
            );
          })}
          {txs.length === 0 && (
            <Card className="text-center text-sm text-slate-400">
              Nenhuma movimentação ainda. Adicione a primeira! 👆
            </Card>
          )}
        </div>
      </section>

      <p className="text-center text-xs text-slate-400">
        Seus dados ficam salvos apenas neste dispositivo.
      </p>

      {formOpen && (
        <TransactionForm onClose={() => setFormOpen(false)} onSave={addTx} />
      )}
    </div>
  );
}

/* ----------------------------- Form ----------------------------- */

function TransactionForm({
  onClose,
  onSave,
}: {
  onClose: () => void;
  onSave: (tx: Omit<Transaction, "id" | "date">) => void;
}) {
  const [type, setType] = useState<TxType>("out");
  const [description, setDescription] = useState("");
  const [value, setValue] = useState("");
  const [category, setCategory] = useState("");

  const available = CATEGORIES.filter((c) => c.type === type);

  function submit(e: React.FormEvent) {
    e.preventDefault();
    const v = Number(value.replace(",", "."));
    if (!description.trim() || !v || v <= 0 || !category) return;
    onSave({ type, description: description.trim(), value: v, category });
  }

  const inputCls =
    "w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none transition focus:border-emerald-400 focus:bg-white focus:ring-2 focus:ring-emerald-100";

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center">
      <div
        onClick={onClose}
        className="absolute inset-0 animate-[fadeIn_0.2s_ease-out] bg-slate-900/40 backdrop-blur-sm"
      />
      <form
        onSubmit={submit}
        className="relative flex max-h-[90vh] w-full flex-col overflow-hidden rounded-t-3xl bg-white shadow-2xl animate-[fadeIn_0.25s_ease-out] sm:max-w-md sm:rounded-3xl"
      >
        <div className="flex justify-center pt-3 sm:hidden">
          <span className="h-1.5 w-10 rounded-full bg-slate-200" />
        </div>
        <div className="flex items-center justify-between px-5 py-4">
          <h3 className="text-lg font-bold text-slate-900">Nova movimentação</h3>
          <button
            type="button"
            onClick={onClose}
            className="flex h-9 w-9 items-center justify-center rounded-full bg-slate-100 text-slate-500"
          >
            ✕
          </button>
        </div>

        <div className="space-y-4 overflow-y-auto px-5 pb-4">
          {/* type toggle */}
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => {
                setType("in");
                setCategory("");
              }}
              className={`flex-1 rounded-xl py-2.5 text-sm font-semibold transition ${
                type === "in"
                  ? "bg-emerald-100 text-emerald-700 ring-2 ring-emerald-200"
                  : "bg-slate-50 text-slate-400"
              }`}
            >
              ↑ Entrada
            </button>
            <button
              type="button"
              onClick={() => {
                setType("out");
                setCategory("");
              }}
              className={`flex-1 rounded-xl py-2.5 text-sm font-semibold transition ${
                type === "out"
                  ? "bg-rose-100 text-rose-600 ring-2 ring-rose-200"
                  : "bg-slate-50 text-slate-400"
              }`}
            >
              ↓ Saída
            </button>
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-500">Descrição</label>
            <input
              autoFocus
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Ex.: Mercado, Salário..."
              className={`mt-1 ${inputCls}`}
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-500">Valor (R$)</label>
            <input
              type="number"
              inputMode="decimal"
              value={value}
              onChange={(e) => setValue(e.target.value)}
              placeholder="0,00"
              className={`mt-1 ${inputCls}`}
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-500">Categoria</label>
            <div className="mt-2 grid grid-cols-3 gap-2">
              {available.map((c) => {
                const on = category === c.id;
                return (
                  <button
                    type="button"
                    key={c.id}
                    onClick={() => setCategory(c.id)}
                    className={`flex flex-col items-center gap-1 rounded-xl border p-2 text-xs font-medium transition ${
                      on
                        ? "border-emerald-400 bg-emerald-50 text-emerald-700"
                        : "border-slate-200 bg-white text-slate-600"
                    }`}
                  >
                    <span className="text-lg">{c.emoji}</span>
                    {c.label}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        <div
          className="border-t border-slate-100 px-5 pt-3"
          style={{ paddingBottom: "max(env(safe-area-inset-bottom), 1rem)" }}
        >
          <Button type="submit" className="w-full">
            Salvar movimentação
          </Button>
        </div>
      </form>
    </div>
  );
}
